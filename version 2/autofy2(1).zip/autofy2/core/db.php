<?php

$dbcon=mysqli_connect("localhost","autofy_user","user@autofy","autofy_db");

//$dbcon=mysqli_connect("localhost","root","","autofy1");
session_start();
?>