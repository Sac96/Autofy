<head>
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="public/css/font-awesome.css">
    <link rel="stylesheet" href="public/css/font-awesome.min.css">
    <link rel="stylesheet" href="public/fonts/fontawesome-webfont.woff2">
</head>
<script src="public/js/jquery.js"></script>
<script src="public/js/bootstrap.min.js"> </script>
