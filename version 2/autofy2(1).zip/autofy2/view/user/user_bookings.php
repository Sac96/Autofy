<?php
include_once './user_header.php';
include_once './user_menubar2.php';
include_once '../../core/db.php';
if (!$_SESSION["lguid"]) {
    echo '<script>window.location.href="./user_login.php"</script>';
}
?>

<?php
$ses = $_SESSION["lguid"];
$qry = 'select * from bookings where user_id=' . $ses;
$try = mysqli_query($dbcon, $qry);

while ($resulttry = mysqli_fetch_array($try)) {

    $rid = $resulttry['booking_id'];
    $subject = $resulttry['booking_msg'];
    $autoid = $resulttry['auto_id'];
    $bkfrom = $resulttry['bkfrom'];
    $bkto = $resulttry['bkto'];
    $bktym = $resulttry['bktime'];
    $bkfor = $resulttry['bkfor'];
    $bkstatus = $resulttry['booking_status'];

    if($bkstatus==0){
        $bkstatus="Pending";
    }elseif ($bkstatus==1) {
        $bkstatus="Accepted";
    }elseif ($bkstatus==2) {
        $bkstatus="Canceled";
    }
    
    
    $qry2 = 'select * from auto where auto_id=' . $autoid;
    $try2 = mysqli_query($dbcon, $qry2);
    while ($resulttry2 = mysqli_fetch_array($try2)) {
        $dname = $resulttry2['driver_name'];
        $regno = $resulttry2['registration_number'];
        $dmob = $resulttry2['driver_mob'];
        ?>

        <div class="col-md-12" style="margin-top: 10px;">
            <h5 class="col-md-3 ">Auto register number:<?php echo $regno; ?></h5>
            <h5 class="col-md-3">Auto Driver Name:<?php echo $dname . '(<a href="tel:' . $dmob . '">' . $dmob . '</a>)' ?></h5>
            <h5 class="col-md-3">Booking Date:<?php echo $bktym ?></h5>
            <div class="col-md-offset-2 col-md-1"><input type="button" <?php echo 'data-rid="' . $rid . '"' ?> value="Delete" class="btn btn-danger delr"> </div>
        </div>
        <div class="container-fluid panel">
            <h4><div class="row panel-body" style="margin-bottom: 10px; margin-top: 50px;">
                <div class="col-md-3">From: <?php echo $bkfrom; ?></div>
                <div class="col-md-3">To: <?php echo $bkto; ?></div>
                <div class="col-md-3">Booking For: <?php echo $bkfor; ?></div>
                <div class="col-md-3" style="color: red;">Booking Status: <?php echo $bkstatus; ?></div></div></h4></div>
                <input type="hidden" id="hdmob" value="<?php echo $dmob;  ?>">
            
        <?php
    }
}
?>

<script src="js/user_bookings.js"></script>