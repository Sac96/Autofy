$('body').on('click', '.delr', function () {
    $rvid = $(this).data('rid');
    $.ajax({
        type: 'post',
        url: './exec/del_review.php',
        data: {rvid: $rvid},
        success: function (response)
        {
            alert('Review removed');            
        }
    });
    window.location.href="./user_reviews.php";

});