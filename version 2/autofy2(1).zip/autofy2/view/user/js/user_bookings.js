$('body').on('click', '.delr', function () {

    $dmob = $('#hdmob').val();

    var cnf = confirm("Please contact the driver to verify your cancelation");

    if (cnf != true) {
    } else {
        window.location.href = "tel://" + $dmob;
    }
    var cnf2 = confirm("Call driver on " + $dmob + " now?!");
    if (cnf2 != true) {
        return false;
    } else {
        $rvid = $(this).data('rid');
        $.ajax({
            type: 'post',
            url: './exec/del_booking.php',
            data: {rvid: $rvid},
            success: function (response)
            {
            }
        });
        alert('Booking canceld');
        window.location.href = "./user_bookings.php";
    }
});




    