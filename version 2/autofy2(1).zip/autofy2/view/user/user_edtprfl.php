<?php
include_once '../../core/db.php';
include_once './user_header.php';
include_once './user_menubar2.php';
?>
<?php


if(!$_SESSION["lguid"])
{
	echo '<script>window.location.href="./user_login.php"</script>';
}

$sessionid=$_SESSION["lguid"];

$kkk= mysqli_query($dbcon, "Select * from user where user_id=".$sessionid);

if($jjj= mysqli_fetch_array($kkk)){
    $nn=$jjj['user_name'];
    $ee=$jjj['user_email'];
    $mm=$jjj['user_mob'];
}
?>

<?php
if (isset($_POST['submitbtn'])) {

    $uname = $_POST['uname'];
    $user_mob = $_POST['user_mob'];
    $user_email = $_POST['user_email'];

    $user_password = $_POST['password'];
    $user_password1 = $_POST['verifypass'];
    $finalpass=sha1($user_password1);



    if ($user_password == $user_password1) {

        $sql="UPDATE `user` SET `user_name`='$uname',`user_email`='$user_email',`user_mob`='$user_mob',`user_password`= '$finalpass' WHERE `user_id`='$sessionid'";
       
        $res = mysqli_query($dbcon, $sql)or die(mysqli_error($dbcon));

        echo '<script> alert("Profile Updated")</script>';
    } else {

        echo '<script language="javascript">';
        echo 'alert("Your password does not match")';
        echo '</script>';
    }
}
?>
<head>
    <title> User Registration</title>
    <link rel="icon" href="images/icon.png" type="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .m-t-10 {
            margin-top: 10px;
        }

        .show_error{
            display: inline;
        }
        .hide_error{
            display: none;
        }
    </style>

</head>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3 col-sm-5 col-sm-offset-4">
            <div class="panel panel-primary" style="margin-top: 30px;">
                <div class="panel-heading" >Update your Profile!</div>
                <div class="panel-body">

                    <form name="reg_form" method="post" action="" enctype="multipart/form-data" onsubmit="return maincheck()" >
                        <label for="fname"> Enter your Name</label>
                        <input type="text" id="uname" value='<?php echo $nn; ?>' class="form-control" onblur="val_name()" name="uname" placeholder="Enter Name" required="">                         
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vname" >Error</div>

                        <label for="Driver Mobile">Mobile Number</label>
                        <input type="text" id="user_mob" value='<?php echo $mm; ?>' pattern="[0-9]{10}" class="form-control" name="user_mob" placeholder="User Phone" onblur="mob_num()">  
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vmob" >Error</div>


                        <label for="emailaddr" class="m-t-10">Email Address</label>
                        <input type="text" id="user_email" value='<?php echo $ee; ?>' class="form-control" onblur="validateEmail()" name="user_email" placeholder="Example: john.smith@gmail.com">
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vemail" >Error</div>

                        <label for="password" class="m-t-10">Password</label>
                        <input type="password" id="password" class="form-control" name="password" onblur="CheckPassword()" placeholder="New Password/Old password" required="">
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vpassword" >Error</div>

                        <label for="verifypass" class="m-t-10">Verify Password</label>
                        <input type="password" id="confirmpass" class="form-control" name="verifypass" placeholder="Confirm Password" required=""> 

                        <center><input type="submit" class="btn btn-primary m-t-10" id="submitbtn"  name="submitbtn" value="Submit"></center>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/get_data.js"></script>
<script src="js/validation.js"></script>

