<head>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="images/icon.png">
</head>
<script src="../../public/js/jquery.js"></script>
<script src="../../public/js/bootstrap.min.js"> </script>