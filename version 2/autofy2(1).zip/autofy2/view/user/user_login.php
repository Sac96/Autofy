<html>
    <head>
        <link rel="icon" href="images/unnamed.png" type="icon">
        <link rel="stylesheet" type="text/css" href="css/login.css">
        <script src='https://www.google.com/recaptcha/api.js'></script>
    </head>
    <?php
    include_once '../../core/db.php';
    include_once './user_header.php';
    include_once './public_menubar.php';
    ?>

    <?php
    if (isset($_POST['login'])) {
        
        
        function CheckCaptcha($userResponse) {
        $fields_string = '';
        $fields = array(
            'secret' => '6LcuGjEUAAAAAMfRMhhVCN8lD5SZIjvtTj61JcOp',
            'response' => $userResponse
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);
        $res = curl_exec($ch);
        curl_close($ch);
        return json_decode($res, true);
    }
    // Call the function CheckCaptcha
    $result = CheckCaptcha($_POST['g-recaptcha-response']);

        if ($result['success']) {

            $uname = $_POST['uname'];
            $pass = $_POST['pass'];
            $lgpass=sha1($pass);

           
            $res = mysqli_query($dbcon, "select * from user where user_email='$uname' and user_password='$lgpass' ");
            $row = mysqli_fetch_array($res);

            if ($row) {

                $_SESSION["lguid"] = $row['user_id'];
                $_SESSION["urname"] = $row['user_name'];

                if (!empty($_POST["remember"])) {
                    setcookie("member_login", $uname, time() + (10 * 365 * 24 * 60 * 60));
                    setcookie("member_password", $pass, time() + (10 * 365 * 24 * 60 * 60));
                } else {
                    if (isset($_COOKIE["member_login"])) {
                        setcookie("member_login", "");
                    }
                    if (isset($_COOKIE["member_password"])) {
                        setcookie("member_password", "");
                    }
                }
                echo '<script> window.location.href="../../index.php" </script>';
            } else {
                ?>
                <script>
                    alert("invalid user");
                </script>
                <?php
            }
        } else {
            echo '<script> alert("Captcha Fail");</script>';
        }
    }
    ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-4 col-md-offset-4">
                <h1 class="text-center login-title">Sign in as User</h1>
                <div class="account-wall">
                    <img class="profile-img" src="images/photo.jpg.png" 
                         alt="">
                    <form class="form-signin" method="post" action="">
                        <input type="text" name="uname" id="uname" value="<?php if (isset($_COOKIE["member_login"])) {
        echo $_COOKIE["member_login"];
    } ?>"  class="form-control" placeholder="Email" required autofocus>
                        <input type="password" name="pass" id="pass" value="<?php if (isset($_COOKIE["member_password"])) {
        echo $_COOKIE["member_password"];
    } ?>" class="form-control" placeholder="Password" required>

                        <!--Site Key-->

                        <div class="g-recaptcha" data-sitekey="6LcuGjEUAAAAAK92iJhRvfxK3ij7nQV1KP6JPdrM"></div>

                        <input type="submit" class="btn btn-lg btn-primary btn-block" name="login" id="login" value="Log In">
                        <label class="checkbox pull-left">
                            <input type="checkbox" value="remember-me" name="remember" id="remember" <?php if (isset($_COOKIE["member_login"])) { ?> checked <?php } ?> />
                            Remember me
                        </label>
                        <a href="user_fgpswd.php" class="pull-right need-help">Forgot Password? </a><span class="clearfix"></span>

                    </form>
                </div>
                <a href="user_reg.php" class="text-center new-account">Create an account </a>
            </div>
        </div>
    </div>
</html>