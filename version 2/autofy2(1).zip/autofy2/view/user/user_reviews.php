<?php
include_once './user_header.php';
include_once './user_menubar2.php';
include_once '../../core/db.php';
if (!$_SESSION["lguid"]) {
    	echo '<script>window.location.href="./user_login.php"</script>';

}
?>
<?php
$ses = $_SESSION["lguid"];
$qry = 'select * from review where user_id=' . $ses;
$try = mysqli_query($dbcon, $qry);

while ($resulttry = mysqli_fetch_array($try)) {

    $rid=$resulttry['review_id'];
    $head = $resulttry['review_head'];
    $subject = $resulttry['review_sub'];
    $dat = $resulttry['review_date'];
    $autoid = $resulttry['auto_id'];

    $qry2 = 'select * from auto where auto_id=' . $autoid;
    $try2 = mysqli_query($dbcon, $qry2);
    while ($resulttry2 = mysqli_fetch_array($try2)) {
        $dname = $resulttry2['driver_name'];
        $regno = $resulttry2['registration_number'];
        ?>

<div class="col-md-12" style="margin-top: 10px;">
            <h4 class="col-md-3 ">Auto register number:<?php echo $regno ; ?></h4>
            <h4 class="col-md-3">Auto Driver Name:<?php echo $dname; ?></h4>
            <h5 style="color: coral;" class="col-md-3">Reviewed on:<?php echo $dat; ?></h5>
            <div class="col-md-3"><input type="button" <?php echo 'data-rid="'.$rid.'"' ?> value="Delete" class="btn btn-danger delr"> </div>
        </div>
        <div class="container-fluid panel">
            <div class="row panel-body" style="margin-bottom: 10px;">
                <div class="col-md-3 col-md-offset-9"></div>
                <div class="col-md-9" style="font-size: 20px; "><?php echo '<p style="color:blue;"><b><i>' . $head . '</i></b></p><p>' . $subject . '</p>'; ?></div>
            </div>

        </div>

        <?php
    }
}
?>
<script src="js/review.js"></script>
