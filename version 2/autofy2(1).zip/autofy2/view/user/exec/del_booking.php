<?php
include_once '../../../core/db.php';
$dr = $_POST['rvid'];
$qry = "delete from bookings where booking_id=" . $dr;
mysqli_query($dbcon, $qry);
?>