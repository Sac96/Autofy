<?php
include_once '../../core/db.php';
include_once './user_menubar.php';
?>
<?php


if(!$_SESSION["lguid"])
{
	header("Location:http://localhost/autofy2/view/user/user_login.php");
}
header("Location:http://localhost/autofy2/index.php");

?>
