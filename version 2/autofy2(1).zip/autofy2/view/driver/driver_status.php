<?php
include_once './driver_header.php';
include_once './driver_menubar.php';
include_once '../../core/db.php';


$sessionid = $_SESSION["lgid"];
echo'<input type="button" style="display:none;" id="sessionid" value="' . $sessionid . '">';


if (!$_SESSION["lgid"]) {
   echo '<script>window.location.href="../../index.php"</script>';
}
?>
<div class="jumbotron"><center><h3 id="h3">Your current status is:</h3></center></div>


<div style="height: 185; width: 700; margin-left: 350; padding: 50; background-color: cornsilk;">

    <center><label> Set your status to</label> <br/><br/>
        <input type="button" id="1" value="Availiable"  class="btn btn-success" style="    margin-right: 50"/>

        <input type="button" id="2" value="Busy" class="btn btn-warning" style="    margin-right: 50"/>


        <input type="button" id="3" value="Not Avaiiable" class="btn btn-danger"/></center>


</div>

<script src="js/driver_status.js"></script>

