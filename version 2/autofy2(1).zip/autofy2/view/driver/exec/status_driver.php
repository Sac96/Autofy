<?php
include_once '../../../core/db.php';

if (isset($_POST['click'])) {

$id1=$_POST['id'];

$qry="UPDATE `auto` SET `status`=1 WHERE `auto_id`=".$id1;

$q = mysqli_query($dbcon, $qry);
}

if (isset($_POST['click1'])) {

$id1=$_POST['id'];

$qry="UPDATE `auto` SET `status`=2 WHERE `auto_id`=".$id1;

$q = mysqli_query($dbcon, $qry);
}

if (isset($_POST['click2'])) {

$id1=$_POST['id'];

$qry="UPDATE `auto` SET `status`=3 WHERE `auto_id`=".$id1;

$q = mysqli_query($dbcon, $qry);
}
?>