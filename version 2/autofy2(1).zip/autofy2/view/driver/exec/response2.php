<?php

if(isset($_POST['acc1']))
{
include_once '../../../core/db.php';
$mob=$_POST['phone'];
$mssid=$_POST['msid'];



function send($sms, $to) {
    
        $sms = urlencode($sms);
      
            $url = 'http://sms.safechaser.com/httpapi/httpapi?token=a917e2ac067a1a6c6d4c40bdd9c47c6d&sender=EYAUTO&number='.$to.'&route=2&type=1&sms='.$sms;
        
            echo $url;
            
            $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $datares = curl_exec($ch);
        curl_close($ch);
        return $datares;
    }
    
    

$msg="Hello user, your request for booking is accepted " ;
send($msg,$mob);

$qry1="UPDATE `bookings` SET `booking_status`=1 WHERE `booking_id`='$mssid'";
$sqlup= mysqli_query($dbcon, $qry1);

}


if(isset($_POST['rej1']))
{
include_once '../../../core/db.php';
$mob=$_POST['phone'];
$mssid=$_POST['msid'];



function send($sms, $to) {
    
        $sms = urlencode($sms);
      
            $url = 'http://sms.safechaser.com/httpapi/httpapi?token=a917e2ac067a1a6c6d4c40bdd9c47c6d&sender=EYAUTO&number='.$to.'&route=2&type=1&sms='.$sms;
        
            echo $url;
            
            $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $datares = curl_exec($ch);
        curl_close($ch);
        return $datares;
    }
    
    

$msg="Hello user, booking for this auto is currently unavailable" ;
send($msg,$mob);




$qry1="UPDATE `bookings` SET `booking_status`=2 WHERE `booking_id`='$mssid'";
$sqlup= mysqli_query($dbcon, $qry1);

}


?>
