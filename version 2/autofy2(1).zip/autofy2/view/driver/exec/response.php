<?php

if(isset($_POST['acc1']))
{
include_once '../../../core/db.php';

$mob=$_POST['phone'];
$mssid=$_POST['msid'];



function send($sms, $to) {
    
        $sms = urlencode($sms);
      
            $url = 'http://sms.safechaser.com/httpapi/httpapi?token=a917e2ac067a1a6c6d4c40bdd9c47c6d&sender=EYAUTO&number='.$to.'&route=2&type=1&sms='.$sms;
        
            echo $url;
            
            $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $datares = curl_exec($ch);
        curl_close($ch);
        return $datares;
    }
    
    

$msg="Hello user, your requested driver will be at your location soon" ;
send($msg,$mob);




$qry1="UPDATE `message` SET `msg_status`=2 WHERE `msg_id`='$mssid'";
$sqlup= mysqli_query($dbcon, $qry1);

}


if(isset($_POST['rej1']))
{
$dbcon=mysqli_connect("localhost","root","","autofy1");
session_start();

$mob=$_POST['phone'];
$mssid=$_POST['msid'];



function send($sms, $to) {
    
        $sms = urlencode($sms);
      
            $url = 'http://sms.safechaser.com/httpapi/httpapi?token=a917e2ac067a1a6c6d4c40bdd9c47c6d&sender=EYAUTO&number='.$to.'&route=2&type=1&sms='.$sms;
        
            echo $url;
            
            $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $datares = curl_exec($ch);
        curl_close($ch);
        return $datares;
    }
    
    

$msg="Hello user, kindly note your requested driver can not provide the service currently" ;
send($msg,$mob);




$qry1="UPDATE `message` SET `msg_status`=0 WHERE `msg_id`='$mssid'";
$sqlup= mysqli_query($dbcon, $qry1);

}


?>
