
<?php
include_once '../../core/db.php';
include_once './driver_header.php';
include_once './public_menubar.php';
?>

<?php
if (isset($_POST['login'])) {
    
    
    function CheckCaptcha($userResponse) {
        $fields_string = '';
        $fields = array(
            'secret' => '6LcuGjEUAAAAAMfRMhhVCN8lD5SZIjvtTj61JcOp',
            'response' => $userResponse
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);
        $res = curl_exec($ch);
        curl_close($ch);
        return json_decode($res, true);
    }
    // Call the function CheckCaptcha
    $result = CheckCaptcha($_POST['g-recaptcha-response']);
    if ($result['success']) {
        //If the user has checked the Captcha box
        //echo "Captcha verified Successfully";
      
        $uname = $_POST['uname'];
        $pass1 = $_POST['pass'];

        $pass=sha1($pass1);
        
        $pass = str_replace("'","", $pass);

        $uname= str_replace("'","", $uname);
        
        
        $res = mysqli_query($dbcon, "select auto_id,driver_name,driver_email,status,driver_password from auto where driver_email='$uname' and driver_password='$pass'");
        $row = mysqli_fetch_array($res);

        
        if ($row) {
            
            
            if($row['status']=='4'){  ?>   
<script>
                alert("Please wait till your account gets approved");
                </script>
           <?php }
else{
    
            $_SESSION["lgid"] = $row['auto_id'];
            $_SESSION["name"] = $row['driver_name'];

            echo '<script>window.location.href="./driver_status.php"</script>';
}
        } else {
            ?>
            <script>
                alert("invalid user");
            </script>
            <?php
        }
    
        
        
    } else {
        // If the CAPTCHA box wasn't checked
       echo '<script>alert("Error Message");</script>';
    }
   
}
?>



<head>
    
    <link rel="icon" href="images/unnamed.png" type="icon">
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <script src='https://www.google.com/recaptcha/api.js'></script>
    
</head>

<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-4 col-md-offset-4">
            <h1 class="text-center login-title">Sign in as Driver</h1>
            <div class="account-wall">
                <img class="profile-img" src="images/photo.jpg.png" 
                     alt="">
                <form class="form-signin" method="post" action="">
                    <input type="text" name="uname" id="uname" class="form-control" placeholder="Email" required autofocus>
                    <input type="password" name="pass" id="pass" class="form-control" placeholder="Password" required>

                    <!--Site Key-->

                    <div class="g-recaptcha" data-sitekey="6LcuGjEUAAAAAK92iJhRvfxK3ij7nQV1KP6JPdrM"></div>



                    <input type="submit" class="btn btn-lg btn-primary btn-block" name="login" id="login" value="Log In">
                    <label class="checkbox pull-left">
                        <input type="checkbox" value="remember-me">
                        Remember me
                    </label>
                    <a href="driver_fgpswd.php" class="pull-right need-help">Forgot Password? </a><span class="clearfix"></span>

                </form>
            </div>
            <a href="driver_reg.php" class="text-center new-account">Create an account </a>
        </div>
    </div>
</div>

