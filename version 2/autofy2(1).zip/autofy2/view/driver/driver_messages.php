<?php
include_once './driver_header.php';
include_once '../../core/db.php';
include_once './driver_menubar.php';

if(!$_SESSION["lgid"])
{
	echo '<script>window.location.href="../../index.php"</script>';
}
?>

<?php
$ses = $_SESSION["lgid"];
$qry = 'select * from message where auto_id=' . $ses.' and msg_status=1 ORDER BY msg_id DESC';
$try = mysqli_query($dbcon, $qry);

while ($resulttry = mysqli_fetch_array($try)) {

    $msgno=$resulttry['msg_content'];
    $msgid=$resulttry['msg_id'];
    $uuid=$resulttry['user_id'];

    $qry2 = 'select * from user where user_id=' . $uuid;
    $try2 = mysqli_query($dbcon, $qry2);
    while ($resulttry2 = mysqli_fetch_array($try2)) {
        $usname = $resulttry2['user_name'];
        $usnum = $resulttry2['user_mob'];
        ?>


        <div class="container-fluid panel">
            <div class="row panel-body" style="margin-bottom: 10px;">
                <div class="col-md-6 "><?php echo $msgno; ?></div>
                <div class="col-md-2 "><?php echo $usname.'  <br/>  '.$usnum; ?></div>
                <div class="col-md-2 "><input type="button" value="Accept" id="accept1"  class="btn-success btn approval2"  data-umob="<?php echo $usnum ; ?>" data-mid="<?php echo $msgid ; ?>" ></div>
                <div class="col-md-2 "><input type="button" value="Reject" id="reject1" class="btn-danger btn reject2" data-umob= "<?php echo $usnum ; ?>" data-mid="<?php echo $msgid ; ?>"></div>
            </div>
        </div>

        <?php
    }
}
?>

<script src="js/inbox.js"></script>
