<?php
include_once '../../core/db.php';
include_once './driver_header.php';
include_once './driver_menubar.php';
?>
<head>
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet">
</head>
<?php
$lgid=$_SESSION["lgid"];
if (!$_SESSION["lgid"]) {
    echo '<script>window.location.href="../../index.php"</script>';
}
?>


<?php

$sqla= mysqli_query($dbcon, "SELECT count(`msg_id`) FROM `message` WHERE `auto_id`=".$lgid." and `msg_status`=1");
$mysqla=mysqli_fetch_array($sqla);

$sqlb= mysqli_query($dbcon, "SELECT count(`booking_id`) FROM `bookings` WHERE `auto_id`=".$lgid." and `booking_status`=0");
$mysqlb=mysqli_fetch_array($sqlb);

$sqlr= mysqli_query($dbcon, "SELECT count(`review_id`) FROM `review` WHERE `auto_id`=".$lgid);
$mysqlr=mysqli_fetch_array($sqlr);

?>

<div class="jumbotron">
    <h2>
        <center> Welcome <?php echo $_SESSION["name"]; ?> </center>
    </h2>
</div>
<div >
    <center>
        <h3>Hello Driver <br> Welcome to Autofy here you can manage your availiability status view your inbox and read reviews about you.
            <br><br><br> You have </h3>
    </center>
</div>

<div class="col-md-12" style="margin-top: 35px;" >
    <div style="height: 180px;width: 250px;background-color: greenyellow;border-radius: 25px;"  class="col-md-offset-2 col-md-3">
        <center style='color: red;font-size: 80px;margin-top: 20px;'>
            <?php echo $mysqla[0]; ?>
        </center>
        <br><center style='margin-top: -10px;font-size: 20px;'>Messages</center>
    </div>   
    <div style="height: 180px;width: 250px;background-color: greenyellow;border-radius: 25px;" class="col-md-offset-1 col-md-3">
          <center style='color: red;font-size: 80px;margin-top: 20px;'>
                        <?php echo $mysqlb[0]; ?>
        </center>
        <br><center style='margin-top: -10px;font-size: 20px;'>Bookings</center>
    </div> 
    <div style="height: 180px;width: 250px;background-color: greenyellow;border-radius: 25px;" class="col-md-offset-1 col-md-2">
        <center style='color: red;font-size: 80px;margin-top: 20px;'>
                        <?php echo $mysqlr[0]; ?>
        </center>
        <br><center style='margin-top: -10px;font-size: 20px;'>Reviews about you</center>
    </div> 
</div>