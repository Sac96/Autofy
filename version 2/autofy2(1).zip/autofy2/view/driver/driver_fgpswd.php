<?php
include_once './public_menubar.php';
include_once './driver_header.php';
include_once '../../core/db.php';


if (isset($_POST['subfg'])) {
    $mail = $_POST['email'];

    $qry = "Select * from auto where driver_email like '" . $mail . "'";
    $sql = mysqli_query($dbcon, $qry);

    if ($row = mysqli_fetch_array($sql)) {
        $num = $row['driver_mob'];
        $pas = $row['driver_password'];
        

        function send($sms, $to) {

            $sms = urlencode($sms);

            $url = 'http://sms.safechaser.com/httpapi/httpapi?token=a917e2ac067a1a6c6d4c40bdd9c47c6d&sender=EYAUTO&number=' . $to . '&route=2&type=1&sms=' . $sms;

            

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_TIMEOUT, 50);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $datares = curl_exec($ch);
            curl_close($ch);
            return $datares;
            
           
        }
        
        $msg = "Hai driver your login credentials are  Username:".$mail." and Password:".$pas;
        send($msg, $num);

         echo '<script> alert("Message sent"); </script> ';

    } else {
        echo '<script>alert("Email does not exist");</script>';
    }
}
?>
<div class="container">
    <div id="passwordreset" style="margin-top:50px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
        <div class="panel panel-info">
            <div class="panel-heading">
                <div class="panel-title">Driver Password Reset</div>
                <div style="float:right; font-size: 85%; position: relative; top:-10px"><a id="signinlink" href="driver_login.php">Sign In</a></div>
            </div>  
            <div class="panel-body" >
                <form id="signupform" class="form-horizontal" method="post" role="form">
                    <div class="form-group">
                        <label for="email" class="col-md-3 control-label">Registered Email</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" name="email" placeholder="Enter your email address that you used to register">
                        </div>
                    </div>

                    <div class="form-group">
                        <!-- Button -->                                        
                        <div class="col-md-offset-3 col-md-9">
                            <input type="submit" name="subfg" value="Send" class="btn btn-warning">                                       
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-12 control">
                            <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                                We'll send your login credentials to your registered mobile number.
                            </div>
                        </div>
                    </div>    

                </form>
            </div>
        </div>
    </div> 
</div>
