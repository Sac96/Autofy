<?php
include_once './driver_header.php';
include_once './driver_menubar.php';
include_once '../../core/db.php';
?>

<?php
$sessionid = $_SESSION["lgid"];
if (!$_SESSION["lgid"]) {
    echo '<script>window.location.href="../../index.php"</script>';
}

$kkk = mysqli_query($dbcon, "Select * from auto where auto_id=" . $sessionid);

if ($jjj = mysqli_fetch_array($kkk)) {
    $q = $jjj['driver_name'];
    $w = $jjj['registration_number'];
    $ee = $jjj['driver_mob'];
    $rr = $jjj['driver_email'];
}


if (isset($_POST['submitbtn'])) {


    $mob = $_POST["driver_mob"];
    $txt = $_POST["driver_email"];
    $msg = "Hai this is yor username:" . $txt . "-team";
//send($msg,$mob);




    $reg_number = $_POST['reg_number'];

    $registration_details = "rc_book_details/" . time() . "" . htmlspecialchars($_FILES['file_upload']['name']);
    move_uploaded_file($_FILES['file_upload']['tmp_name'], $registration_details);

    //echo "<script>alert('$autostand_id')</script>";
    $driver_photo = "driver_photos/" . time() . "" . htmlspecialchars($_FILES['file_upload_photo']['name']);
    move_uploaded_file($_FILES['file_upload_photo']['tmp_name'], $driver_photo);

    $driver_name = $_POST['driver_name'];
    $driver_mob = $_POST['driver_mob'];
    $driver_email = $_POST['driver_email'];

    $driver_password = $_POST['password'];
    $driver_password1 = $_POST['verifypass'];

    $finalpass1 = sha1($driver_password1);

    if ($driver_password == $driver_password1) {

        $sql = "UPDATE `auto` SET `registration_number`='$reg_number',`registration_details`='$registration_details',`driver_photo`='$driver_photo',`driver_name`='$driver_name',`driver_mob`='$driver_mob',`driver_email`='$driver_email',`driver_password`='$finalpass1' WHERE `auto_id`='$sessionid' ";



        $res = mysqli_query($dbcon, $sql)or die(mysqli_error($dbcon));






        echo '<script> alert("Your profile is updated")</script>';
    } else {

        echo '<script language="javascript">';
        echo 'alert("Your password does not match")';
        echo '</script>';
    }
}
?>

<head>
    <title> Update Profile</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .m-t-10 {
            margin-top: 10px;
        }

        .show_error{
            display: inline;           
        }
        .hide_error{
            display: none;
        }
    </style>

</head>
<div class="container">
    <div class="row" style="margin-top: -65;" >
        <div class="col-md-6 col-md-offset-3 col-sm-5 col-sm-offset-4" style="margin-top: 60px;">
            <div class="panel panel-primary" style="margin-top: 20px;">
                <div class="panel-heading" >Update Profile</div>
                <div class="panel-body">

                    <form name="reg_form" method="post" action="#" enctype="multipart/form-data" onsubmit="return !!(validateEmail() & reg_num() & mob_num() & val_name() & CheckPassword())" >
                        <label for="fname"> Vehicle Registration Number</label>
                        <input type="text" id="reg_number" value='<?php echo $w; ?>' class="form-control" onblur="reg_num()" name="reg_number" placeholder="Example: KL 38 AB 6677" required="">                         
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vrnum" >Error</div>

                        <label for="fname"> Vehicle Registration Details</label>
                        <input type="file" id="file_upload"  class="form-control" name="file_upload" >     

                        <!--                    <label for="Add new autostand" style="color:red;"> *Add new autostand</label>
                                            <input type="tel" id="new_autostand" class="form-control" name="new_autostand" placeholder="New Autostand"> -->

                        <label for="Driver Name"> Driver Name</label>
                        <input type="text" id="driver_name" value='<?php echo $q; ?>' onblur="val_name()" class="form-control" name="driver_name" placeholder="Driver Name">  
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vname" >Error</div>

                        <label for="Driver Mobile"> Driver Mobile Number(Add Country Code)</label>
                        <input type="text" id="driver_mob" pattern="[0-9]{10}" value='<?php echo $ee; ?>' class="form-control" name="driver_mob" placeholder="Driver Phone" onblur="mob_num()">  
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vmob" >Error</div>


                        <label for="emailaddr" class="m-t-10">Email Address</label>
                        <input type="text" id="driver_email" value='<?php echo $rr; ?>' class="form-control" onblur="validateEmail()" name="driver_email" placeholder="Example: john.smith@gmail.com">
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vemail" >Error</div>

                        <label for="driver_photo"> Set New Profile Photo</label>
                        <input type="file" id="file_upload_photo" class="form-control" name="file_upload_photo" required="">

                        <label for="password" class="m-t-10"> Set New Password/Old Password</label>
                        <input type="password" id="password" class="form-control" onblur="CheckPassword()" name="password" placeholder="Password here!">
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vpassword" >Error</div>

                        <label for="verifypass" class="m-t-10">Verify Password</label>
                        <input type="password" id="confirmpass" class="form-control" name="verifypass" placeholder="Confirm Password">

                        <center><input type="submit" class="btn btn-primary m-t-10" id="submitbtn"  name="submitbtn" value="Submit"></center>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/validation.js"></script>
