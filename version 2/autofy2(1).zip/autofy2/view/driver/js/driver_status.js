
$('body').on('click', '#1', function () {


$idclick=$('#1').val();
$sessionid=$('#sessionid').val();

    $.ajax({
        type: 'post',
        url: './exec/status_driver.php',
        data: {id:$sessionid,click:$idclick},
        success: function (response)
        {
            $('#h3').html("Your current status is : Availiable");

        }
    });
});


$('body').on('click', '#2', function () {


$idclick=$('#2').val();
$sessionid=$('#sessionid').val();

    $.ajax({
        type: 'post',
        url: './exec/status_driver.php',
        data: {id:$sessionid,click1:$idclick},
        success: function (response)
        {
            $('#h3').html("Your current status is : Busy");

        }
    });
});

$('body').on('click', '#3', function () {


$idclick=$('#3').val();
$sessionid=$('#sessionid').val();
    $.ajax({
        type: 'post',
        url: './exec/status_driver.php',
        data: {id:$sessionid,click2:$idclick},
        success: function (response)
        {
            $('#h3').html("Your current status is : Not Availiable");

        }
    });
});