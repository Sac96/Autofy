$('body').on('click', '.approval2', function () {


    $phone = $(this).data('umob');
    $acc=$('#accept1').val();
    $mid = $(this).data('mid');
    
    
    
     $.ajax({
        type: 'post',
        url: './exec/response.php',
        data: {phone: $phone,msid: $mid,acc1: $acc},
        success: function (response)

        {
           alert('Accepted');
        }
    });
    
});

$('body').on('click', '.reject2', function () {


    $phone = $(this).data('umob');
    $rej=$('#reject1').val();
    $mid = $(this).data('mid');
    
    
    
     $.ajax({
        type: 'post',
        url: './exec/response.php',
        data: {phone: $phone,msid: $mid,rej1: $rej},
        success: function (response)

        {
            alert('Rejected');
        }
    });
    
});