/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$('body').on('click', '.approval2', function () {


    $phone = $(this).data('umob');
    $acc=$('#accept1').val();
    $mid = $(this).data('mid');
    
    
    
     $.ajax({
        type: 'post',
        url: './exec/response2.php',
        data: {phone: $phone,msid: $mid,acc1: $acc},
        success: function (response)

        {
           alert('Accepted');
        }
    });
    
});

$('body').on('click', '.reject2', function () {


    $phone = $(this).data('umob');
    $rej=$('#reject1').val();
    $mid = $(this).data('mid');
    
    alert("Once accepted, you shold call the passenger to confirm the booking is canceld");
    
     $.ajax({
        type: 'post',
        url: './exec/response2.php',
        data: {phone: $phone,msid: $mid,rej1: $rej},
        success: function (response)

        {
            alert('Rejected');
        }
    });
    
});