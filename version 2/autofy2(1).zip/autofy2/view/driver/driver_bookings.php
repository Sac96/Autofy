<?php
include_once './driver_header.php';
include_once '../../core/db.php';
include_once './driver_menubar.php';

if (!$_SESSION["lgid"]) {
    echo '<script>window.location.href="../../index.php"</script>';
}
?>

<?php
$ses = $_SESSION["lgid"];
$qry = 'select * from bookings where auto_id=' . $ses . ' ORDER BY booking_id DESC';
$try = mysqli_query($dbcon, $qry);

$qry22="delete from bookings where datediff(now(), bookings.date) > 5";
$try22 = mysqli_query($dbcon, $qry22);

while ($resulttry = mysqli_fetch_array($try)) {

    $bgmsg = $resulttry['booking_msg'];
    $bgid = $resulttry['booking_id'];
    $uuid = $resulttry['user_id'];
    $bkfrom = $resulttry['bkfrom'];
    $bkto = $resulttry['bkto'];
    $bktym = $resulttry['bktime'];
    $bkfor = $resulttry['bkfor'];
    $bkstatus = $resulttry['booking_status'];


    if ($bkstatus == 0) {
        $bkstatus = "Pending";
    } elseif ($bkstatus == 1) {
        $bkstatus = "Accepted";
    } elseif ($bkstatus == 2) {
        $bkstatus = "Canceled";
    }

    $qry2 = 'select * from user where user_id=' . $uuid;
    $try2 = mysqli_query($dbcon, $qry2);
    while ($resulttry2 = mysqli_fetch_array($try2)) {
        $usname = $resulttry2['user_name'];
        $usnum = $resulttry2['user_mob'];
        ?>
<?php if($bkstatus == "Canceled"){  }
 else { ?>

        <div class="col-md-12" style="margin-top: 10px;">
            <h5 class="col-md-3 "></h5>
            <h5 class="col-md-3">Booking by:<?php echo $usname . '(<a href="tel:' . $usnum . '">' . $usnum . '</a>)' ?></h5>
            <h5 class="col-md-3">Booking Date:<?php echo $bktym ?></h5>
            <?php if ($bkstatus == "Accepted") { ?> 
                <div class="col-md-offset-1 col-md-1"><input type="button" value="Accepted"  class="btn-success btn "  data-umob="<?php echo $usnum; ?>" data-mid="<?php echo $bgid; ?>" ></div>
            <?php } else { ?>
                <div class="col-md-offset-1 col-md-1"><input type="button" value="Accept" id="accept1"  class="btn-success btn approval2"  data-umob="<?php echo $usnum; ?>" data-mid="<?php echo $bgid; ?>" ></div>
            <?php } ?>
            <div class="col-md-1 "><input type="button" value="Reject" id="reject1" class="btn-danger btn reject2" data-umob= "<?php echo $usnum; ?>" data-mid="<?php echo $bgid; ?>"></div>
        </div>
        <div class="container-fluid panel"  >
            <h4><div class="row panel-body" style="margin-bottom: 10px; margin-top: 100px;">
                    <div class="col-md-3">From: <?php echo $bkfrom; ?></div>
                    <div class="col-md-3">To: <?php echo $bkto; ?></div>
                    <div class="col-md-3">Booking For: <?php echo $bkfor; ?></div>
                    <div class="col-md-3" style="color: red;">Booking Status: <?php echo $bkstatus; ?></div></div></h4></div>
                <?php }    ?>
        <input type="hidden" id="hdmob" value="<?php echo $usnum; ?>">
     
        <?php
    }
}
?>

<script src="js/driver_bookings.js"></script>
