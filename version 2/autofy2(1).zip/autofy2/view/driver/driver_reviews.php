<?php
include_once './driver_header.php';
include_once '../../core/db.php';
include_once './driver_menubar.php';

if(!$_SESSION["lgid"])
{
	echo '<script>window.location.href="../../index.php"</script>';
}
?>

<?php
$ses = $_SESSION["lgid"];
$qry = 'select * from review where auto_id=' . $ses.' ORDER BY review_id DESC';
$try = mysqli_query($dbcon, $qry);

while ($resulttry = mysqli_fetch_array($try)) {

    $rid=$resulttry['review_id'];
    $head = $resulttry['review_head'];
    $subject = $resulttry['review_sub'];
    $autoid = $resulttry['auto_id'];

    $qry2 = 'select * from auto where auto_id=' . $autoid;
    $try2 = mysqli_query($dbcon, $qry2);
    while ($resulttry2 = mysqli_fetch_array($try2)) {
        $dname = $resulttry2['driver_name'];
        $regno = $resulttry2['registration_number'];
        ?>


        <div class="container-fluid panel">
            <div class="row panel-body" style="margin-bottom: 10px;">
                <div class="col-md-3 col-md-offset-9"></div>
                <div class="col-md-9" style="font-size: 20px "><?php echo '<p style="color:blue;"><b><i>' . $head . '</i></b>:</p><p>' . $subject . '</p>'; ?></div>
            </div>

        </div>

        <?php
    }
}
?>

