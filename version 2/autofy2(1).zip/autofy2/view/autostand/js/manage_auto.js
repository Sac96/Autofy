$('body').on('click', '.autoupdate', function () {

    $id = $(this).data('autoid');
    

    $.ajax({
        type: 'post',
        url: './exec/auto_manage.php',
        data: {updateid: $id},
        success: function (response)

        {
            alert('Approved');

        }
    });
});

$('body').on('click', '.autodelete', function () {

    $id = $(this).data('autodid');
    var cf=confirm("Do you want to remove the driver?!");
    if (cf!=true){
        return false;
    }
else{
    $.ajax({
        type: 'post',
        url: './exec/auto_manage.php',
        data: {deleteid: $id},
        success: function (response)

        {
            alert('Removed');
            $('#autostand_select').html($str);

        }
    });
};

});