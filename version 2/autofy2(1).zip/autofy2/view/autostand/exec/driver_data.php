<?php
include_once '../../../core/db.php';

$drid = $_POST['did'];

$dqry = "SELECT * FROM `auto` WHERE auto_id=" . $drid;
$dsql = mysqli_query($dbcon, $dqry);
$dres = mysqli_fetch_array($dsql);

if ($dres) {
    $dname = $dres['driver_name'];
    $dmob = $dres['driver_mob'];
    $daddr = $dres['driver_address'];
    $demail = $dres['driver_email'];
    $duidai = $dres['driver_uidai'];
    $dpic = $dres['driver_photo'];
    $dreg = $dres['registration_number'];
}
?>
<div class="row">
    <div class="col-md-7">
        <label> Driver Name :</label> <?php echo $dname; ?><br><br>
        <label> Driver Mobile :</label> <?php echo $dmob; ?><br><br>
        <label> Driver Email :</label> <?php echo $demail; ?><br><br>
        <label> Driver Aadhar Number :</label> <?php echo $duidai; ?><br><br>
        <label> Driver Address :</label> <?php echo $daddr; ?><br><br>
        <label> Vehicle Registration Number :</label> <?php echo $dreg; ?><br><br>
    </div>

    <div class="col-md-5"><?php echo '<div class="col-md-2" ><img src="../driver/' . $dpic . '"  style="width:128px;height:128px;border-radius:80px;"></div>'; ?></div>
</div>

