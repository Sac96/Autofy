<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            div{
                height: 605px   ;
                position: absolute;
                overflow: hidden;
                width: 1140px;
            }
            iframe{
                position: absolute;
                height: 2000px;
                width: 1500px;
                right: -182px;
                top: -534px;
            }
        </style>
    </head>
    <body>
        <div>
            <iframe src="https://www.maps.ie/coordinates.html">

            </iframe>
        </div>
    </body>
</html>

