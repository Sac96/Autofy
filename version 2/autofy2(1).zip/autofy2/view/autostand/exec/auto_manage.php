<?php
include_once '../../../core/db.php';

if(isset($_POST['updateid']))
{
$aid=$_POST['updateid'];

$query="UPDATE `auto` SET `status`= 2  WHERE `auto_id`=".$aid;
$sql= mysqli_query($dbcon, $query);
}

if(isset($_POST['deleteid']))
{
$aid=$_POST['deleteid'];    

$query="UPDATE `auto` SET `status`= 0  WHERE `auto_id`=".$aid;
$sql= mysqli_query($dbcon, $query);
}



?>
