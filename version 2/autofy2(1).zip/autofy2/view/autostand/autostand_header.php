<head>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../../public/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../public/fonts/fontawesome-webfont.woff2">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body{
            background-color: darkgray;
        }
    </style>
</head>
<script src="../../public/js/jquery.js"></script>
<script src="../../public/js/bootstrap.min.js"> </script>
