<?php
include_once './autostand_header.php';
include_once './autostand_menubar.php';
session_start();


$b = $_SESSION["autostand_lgname"];
if (!$_SESSION["autostand_lgid"]) {
    header("Location:http://localhost/autofy2/index.php");
}
header("Location:http://localhost/autofy2/index.php");
?>


<div class="jumbotron">
    <h2>
        <center> Welcome <?php echo $b; ?> </center>
    </h2>
</div>