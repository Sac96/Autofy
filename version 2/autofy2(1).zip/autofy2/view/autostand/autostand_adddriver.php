<?php
include_once './autostand_header.php';
include_once './autostand_menubar.php';
include_once '../../core/db.php';
?>
<?php
$sessionid = $_SESSION["autostand_lgid"];
if (!$_SESSION["autostand_lgid"]) {
    echo '<script>window.location.href="../../index.php";</script>';
}
?>

<?php

function send($sms, $to) {

    $sms = urlencode($sms);

    $url = 'http://sms.safechaser.com/httpapi/httpapi?token=a917e2ac067a1a6c6d4c40bdd9c47c6d&sender=EYAUTO&number=' . $to . '&route=2&type=1&sms=' . $sms;


    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 50);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $datares = curl_exec($ch);
    curl_close($ch);
    return $datares;
}
?>

<?php
//$password= rand(10000000,99999999);
//    echo sha1($password);

$atd = $_SESSION["autostand_lgid"];
if (isset($_POST['submitbtn'])) {

    $password = rand(10000000, 99999999);

    $mob = $_POST["driver_mob"];
    $txt = $password;
    $msg = "Hello driver,Login to autofy with the password " . $txt . " using your email";
    send($msg, $mob);




    $reg_number = $_POST['reg_number'];

    $registration_details = "../driver/rc_book_details/" . time() . "" . htmlspecialchars($_FILES['file_upload']['name']);
    move_uploaded_file($_FILES['file_upload']['tmp_name'], $registration_details);

    $autostand_id = $atd;
    $driver_name = $_POST['driver_name'];
    $driver_mob = $_POST['driver_mob'];
    
    $driver_addr=$_POST['driver_addr'];
    $driver_uidai=$_POST['driver_uidai'];
    
    $driver_email = $_POST['driver_email'];
    $driver_password = sha1($password);

//    $driver_password = $_POST['password'];
//    $driver_password1 = $_POST['verifypass'];




    $sql = "INSERT INTO `auto`(`registration_number`, `registration_details`, `driver_name`, `driver_mob`, `driver_address`,`driver_uidai`,`driver_email`, `driver_password`, `status`, `autostand_id`) VALUES ('$reg_number','$registration_details','$driver_name','$driver_mob','$driver_addr','$driver_uidai','$driver_email','$driver_password',3,'$autostand_id')";

    $res = mysqli_query($dbcon, $sql)or die(mysqli_error($dbcon));


    $p = "select max(auto_id) as lgid from auto";

    $q = mysqli_query($dbcon, $p) or die(mysqli_error($dbcon));
    $row = mysqli_fetch_array($q);
    $x = $row['lgid'];




    echo '<script> alert("Registration Successful Please Login")</script>';
}
?>

<head>
    <title> Driver Registration</title>
    <link rel="icon" href="images/icon.png" type="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .m-t-10 {
            margin-top: 10px;
        }

        .show_error{
            display: inline;           
        }
        .hide_error{
            display: none;
        }
    </style>

</head>
<div class="container">
    <div class="row" style="margin-top: -65;">
        <div class="col-md-6 col-md-offset-3 col-sm-5 col-sm-offset-4" style=" margin-top: 70;">
            <div class="panel panel-primary" style="margin-top: 20px;">
                <div class="panel-heading" >Register your Auto!</div>
                <div class="panel-body">

                    <form name="reg_form" method="post" action="#" enctype="multipart/form-data" onsubmit="return !!(validateEmail() & reg_num() & mob_num() & val_name() & CheckPassword())" >
                        <label for="fname"> Vehicle Registration Number</label>
                        <input type="text" id="reg_number" class="form-control" onblur="reg_num()" name="reg_number" placeholder="Example: KL 38 AB 6677" required="">                         
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vrnum" >Error</div>

                        <label for="fname"> Vehicle Registration Details</label>
                        <input type="file" id="file_upload" class="form-control" name="file_upload" required="">     

                        <label for="Driver Name"> Driver Name</label>
                        <input type="text" id="driver_name" onblur="val_name()" class="form-control" name="driver_name" placeholder="Driver Name">  
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vname" >Error</div>

                        <label for="Driver Mobile"> Driver Mobile Number(Add Country Code)</label>
                        <input type="text" id="driver_mob" pattern="[0-9]{10}"  title="eg:+9567279288" class="form-control" name="driver_mob" placeholder="Driver Phone" onblur="mob_num()">  
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vmob" >Error</div>

                        <label for="Driver Address"> Residential Address</label>
                        <textarea id="driver_addr" class="form-control" name="driver_addr" placeholder="Driver Address" required=""></textarea>

                        <label for="driver_photo"> Driver UIDAI</label>
                        <input type="text" id="driver_uidai" pattern="[0-9]{12}" title="Must be of 12 numbers" placeholder="Driver Aadhar Number" class="form-control" name="driver_uidai" required="">     


                        <label for="emailaddr" class="m-t-10">Email Address</label>
                        <input type="text" id="driver_email" class="form-control" onblur="validateEmail()" name="driver_email" placeholder="Example: john.smith@gmail.com">
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vemail" >Error</div>

                        <!--                        <label for="password" class="m-t-10">Password</label>
                                                <input type="password" id="password" class="form-control" onblur="CheckPassword()" name="password" placeholder="Password here!">
                                                <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vpassword" >Error</div>
                        
                                                <label for="verifypass" class="m-t-10">Verify Password</label>
                                                <input type="password" id="confirmpass" class="form-control" name="verifypass" placeholder="Confirm Password">-->

                        <center><input type="submit" class="btn btn-primary m-t-10" id="submitbtn"  name="submitbtn" value="Register new Auto"></center>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/validation.js"></script>