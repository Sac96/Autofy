<?php
include_once '../../core/db.php';
include_once './autostand_header.php';
include_once './autostand_menubar.php';

?>


<?php

$k=$_SESSION["autostand_lgid"];

if(!$k){
     echo '<script>window.location.href="../../index.php";</script>';
}
        
$sql= "SELECT * FROM `auto` WHERE `autostand_id=".$k."`";
$qry = mysqli_query($dbcon, $sql);

?>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">   
    <style>
        .clickable
        {
            cursor: pointer;
        }

        .clickable .glyphicon
        {
            background: rgba(0, 0, 0, 0.15);
            display: inline-block;
            padding: 6px 12px;
            border-radius: 4px
        }

        .panel-heading span
        {
            margin-top: -23px;
            font-size: 15px;
            margin-right: -9px;
        }
        a.clickable { color: inherit; }
        a.clickable:hover { text-decoration:none; }
    </style>
</head>

<h4>
    Manage autos in your stand
</h4>


<div class="container-fluid">
    
   
    
    <div class="panel panel-info"> 
        <div class="panel-heading clickable">
            <h3 class="panel-title">
                Hello <?php echo $_SESSION["autostand_lgname"]; ?></h3>

            <span class="pull-right "><i class="glyphicon glyphicon-minus"></i></span>
        </div>
        <div class="panel-body">

             <div class="col-md-12">
                        <?php
                        $sql= mysqli_query($dbcon,"SELECT * FROM `auto` WHERE `status` > 0 and `autostand_id`=".$k);
                        
                        echo '<div class="row" style="margin-bottom:30px;    font-size: 20px;">';
                            echo '<b><center><div class="col-md-2">Driver Name</div>';
                            echo '<div class="col-md-2">Driver Phone</div>';
                            echo '<div class="col-md-2">Registration Details</div>';
                            echo '<div class="col-md-2">Reviews</div>';
                            echo '<div class="col-md-2">Status</div>';
                            echo '<div class="col-md-2"></div>';
                            echo '<br/><br/><hr/>';
                            echo '</center></div></b>';
                        
                        //$autos = mysqli_query($dbcon, "SELECT * FROM `autostand` WHERE `place_id`='" . $a . "' AND `status` =1");
                        while ($result2 = mysqli_fetch_array($sql)) {
                            
                            $aa=$result2['auto_id'];
                            $n=$result2['driver_name'];
                            $r= $result2['registration_details'];
                            $e = $result2['driver_email'];
                            $rg = $result2['registration_number'];
                            $m = $result2['driver_mob'];
                            $atsts=$result2['status'];



                            echo '';
                            echo '<div class="row" style="margin-bottom:30px;    font-size: 20px;">';
                            echo '<center ><div class="col-md-2" style="margin-top: 60;" ><div style="float:left;"><i class="fa fa-user fa-1x" aria-hidden="true"></i></div>&nbsp;<a  id="dprofile" data-id="' . $aa . '" >' . $n . '</a></div>';
                            echo '<div class="col-md-2" style="margin-top: 60;"><i class="fa fa-phone fa-1x" aria-hidden="true"></i>&nbsp;<a href="tel:' . $m . '">' . $m . '</a></div>';
                            echo '<div class="col-md-2" ><a href="../../view/driver/' . $r . '" target="_blank"><img src="../../view/driver/' . $r . '"  style="width:128px;height:128px"></a> </div>';
                            echo '<div class="col-md-2" style="margin-top: 60;"><input type="button" value="Review" class="review1 btn btn-primary" data-id="' . $aa . '" data-mob="' . $m . '" data-name="' . $n . '"></div>';
                            if($atsts==4){
                            echo '<div class="col-md-2" style="margin-top: 60;"> <input type="button" value="Approve" class="autoupdate btn btn-success"  data-autoid="'.$aa .'" > </div>';
                            } else {
                                echo '<div class="col-md-2" style="margin-top: 60;"> <input type="button" value="Approved" class="btn btn-success"> </div>';
                            }
                            echo '<div class="col-md-2" style="margin-top: 60;"> <input type="button" value="Remove" class="autodelete btn btn-danger"  data-autodid="'.$aa .'" > </div>';

                            echo '</center></div>';
                            echo '';
                         
                            
                        }
                        ?>
                 
                 <div class="col-md-12" id="review<?php echo $aa; ?>">

                            </div>

                    </div>  


        </div>
    </div>
    
</div>

<!-- Modal -->
        <div class="modal fade" id="uprofilemodal" role="dialog">


            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content" style="background-color: beige;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Driver Details</h4>
                    </div>
                    <div class="modal-body" id="apbody" >

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
                <!--Modal Content Ends-->
            </div>

        </div>
        <!--Modal ends-->



<script>
    $(document).on('click', '.panel-heading span.clickable', function (e) {
        var $this = $(this);
        if (!$this.hasClass('panel-collapsed')) {
            $this.parents('.panel').find('.panel-body').slideUp();
            $this.addClass('panel-collapsed');
            $this.find('i').removeClass('glyphicon-minus').addClass('glyphicon-plus');
        } else {
            $this.parents('.panel').find('.panel-body').slideDown();
            $this.removeClass('panel-collapsed');
            $this.find('i').removeClass('glyphicon-plus').addClass('glyphicon-minus');
        }
    });
    $(document).on('click', '.panel div.clickable', function (e) {
        var $this = $(this);
        if (!$this.hasClass('panel-collapsed')) {
            $this.parents('.panel').find('.panel-body').slideUp();
            $this.addClass('panel-collapsed');
            $this.find('i').removeClass('glyphicon-minus').addClass('glyphicon-plus');
        } else {
            $this.parents('.panel').find('.panel-body').slideDown();
            $this.removeClass('panel-collapsed');
            $this.find('i').removeClass('glyphicon-plus').addClass('glyphicon-minus');
        }
    });
    $(document).ready(function () {
        $('.panel-heading span.clickable').click();
//        $('.panel div.clickable').click();
    });

</script>

<script src="js/manage_auto.js"></script>
<script src="js/review.js"></script>

