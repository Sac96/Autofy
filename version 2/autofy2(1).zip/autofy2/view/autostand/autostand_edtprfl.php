<?php
include_once './autostand_header.php';
include_once './autostand_menubar.php';
include_once '../../core/db.php';
?>

<?php
$sessionid = $_SESSION["autostand_lgid"];
if (!$_SESSION["autostand_lgid"]) {
   echo '<script>window.location.href="../../index.php";</script>';
}

$kkk = mysqli_query($dbcon, "Select * from autostand where autostand_id=" . $sessionid);

if ($jjj = mysqli_fetch_array($kkk)) {
    $q = $jjj['autostand_name'];
    $w = $jjj['association_id'];
    $ee = $jjj['pincode'];
    $rr = $jjj['autostand_phone'];
    $tt = $jjj['autostand_mail'];
}


if (isset($_POST['submitbtn'])) {


   // $mob = $_POST["driver_mob"];
   // $txt = $_POST["driver_email"];
   // $msg = "Hai this is yor username:" . $txt . "-team";
//send($msg,$mob);




  $association_id = $_POST['association_id'];
    $autostand_name = $_POST['autostand_name'];


    $pincode = $_POST['pincode'];

    $autostand_phone = $_POST['autostand_phone'];

    $autostand_email = $_POST['autostand_email'];

    $autostand_password = $_POST['password'];
    $autostand_password1 = $_POST['verifypass'];
    
    $finalpass=sha1($_POST['verifypass']);


    if ($autostand_password == $autostand_password1) {
       // $sqlll = "INSERT INTO `autostand`(`association_id`, `autostand_name`, `autostand_img`, `pincode`, `autostand_phone`, `autostand_mail`, `autostand_password`, `status`, `place_id`) VALUES ('$association_id','$autostand_name','$autostand_img','$pincode','$autostand_phone','$autostand_email','$autostand_password1',2,'$place_id')";

       $sql= "UPDATE `autostand` SET `association_id`='$association_id',`autostand_name`='$autostand_name',`pincode`='$pincode',`autostand_phone`='$autostand_phone',`autostand_mail`='$autostand_email',`autostand_password`='$finalpass' WHERE `autostand_id`='$sessionid' ";
        
        $res = mysqli_query($dbcon, $sql)or die(mysqli_error($dbcon));


        echo '<script> alert("Your profile is updated")</script>';
    } else {

        echo '<script language="javascript">';
        echo 'alert("Your password does not match")';
        echo '</script>';
    }
}
?>

<head>
    <title> Update Profile</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .m-t-10 {
            margin-top: 10px;
        }

        .show_error{
            display: inline;           
        }
        .hide_error{
            display: none;
        }
    </style>

</head>
<div class="container">
    <div class="row" style="margin-top: -65;" >
        <div class="col-md-6 col-md-offset-3 col-sm-5 col-sm-offset-4" style="margin-top: 70px;">
            <div class="panel panel-primary" style="margin-top: 20px;">
                <div class="panel-heading" >Update AutoStand!</div>
                <div class="panel-body">

                    <form name="association_id" method="post" action="" enctype="multipart/form-data" onsubmit="" >
                        <label for="fname"> Association ID</label>
                        <input type="text" id="association_id" value="<?php echo $w; ?>" class="form-control" name="association_id" placeholder="Association ID" required="">                         

                        <label for="autostand_name"> AutoStand Name</label>
                        <input type="text" id="autostand_name" value="<?php echo $q; ?>" class="form-control" name="autostand_name" onblur="val_name()" placeholder="Stand Name" required="">                         
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vname" >Error</div>

<!--                        <label for="fname"> AutoStand Image</label>
                        <input type="file" id="file_upload" class="form-control" name="file_upload" >     -->
                       
                        <label for="Driver Name"> Pincode</label>
                        <input type="tel" id="pincode" value="<?php echo $ee; ?>" class="form-control" name="pincode" pattern="[0-9]{6}" placeholder="Driver Name">  

                        <label for="Driver Mobile"> AutoStand Phone Number</label>
                        <input type="text" id="autostand_phone" pattern="[0-9]{10}" value="<?php echo $rr; ?>" class="form-control" name="autostand_phone" placeholder="Driver Phone" onblur="mob_num()">  
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vmob" >Error</div>


                        <label for="emailaddr" class="m-t-10">Email Address</label>
                        <input type="text" id="autostand_email" value="<?php echo $tt; ?>" class="form-control" onblur="validateEmail()" name="autostand_email" placeholder="Example: autostand@mail.com">
                        <div class="row col-md-12 hide_error " style="color:red; font-size: 20px;" id="vemail" >Error</div>

                        <label for="password" class="m-t-10">New Password/Old password</label>
                        <input type="password" id="password" class="form-control" pattern="[A-Za-z0-9]{8,16}" title="Minimum 8 alphabets or numbers" name="password" placeholder="Password here!" required="">

                        <label for="verifypass" class="m-t-10">Verify Password</label>
                        <input type="password" id="confirmpass" class="form-control" name="verifypass" placeholder="Confirm Password" required="">

                        <center><input type="submit" class="btn btn-primary m-t-10" id="submitbtn" name="submitbtn" value="Submit"></center>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/validate_stand.js"></script>
