<?php

session_start();
session_unset();
session_destroy();
echo '<script>window.location.href="./autostand_login.php";</script>';
?>