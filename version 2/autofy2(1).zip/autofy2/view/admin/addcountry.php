<?php
include_once '../../core/db.php';
include_once 'admin_header.php';
include_once './admin_menubar.php';
?>

<?php
if (!$_SESSION["adlgid"]) {
     echo '<script> window.location.href="../../index.php"</script>';
}
?>

<?php
if (isset($_POST['add'])) {
    $country = $_POST['add_country'];

    $sql = "INSERT INTO `country`(`country_name`, `status`) VALUES ('$country',1)";
    $res = mysqli_query($dbcon, $sql);
    echo '<script>alert("Country added");</script>';
}
?>
<head>
    <link rel="icon" href="images/icon.png" type="icon">
</head>




<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3 col-sm-5 col-sm-offset-4">
            <div class="panel panel-primary" style="margin-top: 20px;">
                <div class="panel-heading" >Register your Auto!</div>
                <div class="panel-body">

                    <form name="add_country_form" method="post" action="" enctype="multipart/form-data" onsubmit="check1()" >
                        <label for="fname"> Add New Country</label>
                        <input type="text" pattern="[A-Z][a-z]*" id="add_country" class="form-control" onblur="check1()" name="add_country" placeholder="New Country Name" required="">                         

                        <center><input type="submit" class="btn btn-primary m-t-10" id="add" name="add" value="Add Country" style="margin-top: 5px;"></center>

                    </form>


                    <br><label for="Heading"> Edit/Remove existing countries </label><br><br>

                    <label for="states" class="m-t-10">Select your Country</label>

                    <select id="country_select" class="form-control" name="country" required=""> 
                        <option selected="" disabled="" value="-1">Country</option>
                        <?php
                        $res = mysqli_query($dbcon, "select * from country where status='1' ");

                        while ($row = mysqli_fetch_array($res)) {
                            $cty = $row['country_name'];
                            echo '<option value=' . $row['country_id'] . '>' . $row['country_name'] . '</option>';
                        }
                        ?>
                    </select>


                    <label for="Driver Name"> Set new name </label>
                    <input type="text" id="textedit" pattern="[A-Z][a-z]*" class="form-control" name="textrdit" placeholder="New Name">  


                    <input type="button" class="btn btn-warning m-t-10" id="btnedit" name="btnedit" value="Edit" style="float: left;margin-top:5px; ">

                    <input type="button" class="btn btn-danger m-t-10" id="btndelete" name="btndelete" value="Delete" style="float: right;margin-top:5px;">


                </div>
            </div>
        </div>
    </div>
</div>  




<script src="js/editcountry.js"></script>

<script>
                            function check1() {

                                $kkk = $('#add_country').val();

                                $.ajax({
                                    type: 'post',
                                    url: 'exec/editcountry.php',
                                    data: {cty: $kkk},
                                    success: function (response)
                                    {
                                        if ((response) == 0)
                                        {
                                            return true;
                                        } else {
                                            
                                            alert('Data already exists');
                                            return false;
                                        }

                                    }
                                });

                                var x = document.getElementById("add_country").value;
                                if (x == "")
                                {
                                    alert('Please enter valid name')
                                    return false;
                                } else {
                                    return true;
                                }
                            }

</script>













