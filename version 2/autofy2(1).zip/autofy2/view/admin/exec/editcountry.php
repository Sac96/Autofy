<?php

include_once '../../../core/db.php';


if (isset($_POST['temp1'])) {
    $a = $_POST['index1'];
    $b = $_POST['temp1'];

    $q1= mysqli_query($dbcon, "UPDATE `country` SET `country_name`='" . $a . "' where `country_id`='" . $b . "' ");    
}

if(isset($_POST['temp2'])){
    $temp2 = $_POST['temp2'];
    $q2=mysqli_query($dbcon, "DELETE FROM `country` WHERE `country_id`='" . $temp2 . "' ");
}


if (isset($_POST['cty'])) {
    $a = $_POST['cty'];

    $q1= mysqli_query($dbcon, "Select count(*) from country where `country_name`='" . $a . "'");    
    $f= mysqli_fetch_array($q1);
    
    echo $f[0];
           
    
    
    
}
?>

