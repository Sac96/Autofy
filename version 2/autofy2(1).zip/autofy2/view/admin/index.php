<?php
include_once '../../core/db.php';
?>
<script>
window.location.href="./admin_login.php";
</script>