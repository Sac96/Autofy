$('body').on('click', '#add', function () {

    $country_selected = $('#country_select').val();
    $add_state = $('#add_state').val();

if($add_state == ""){
    alert('Add a value');
}
else{
    


    $.ajax({
        type: 'post',
        url: 'exec/edit_state.php',
        data: {country: $country_selected, state: $add_state},
        success: function (response)
        {
alert('State added')
        }
    });
    }
});

$('body').on('change', '#country_edit_select', function () {

    $select_state = $('#country_edit_select').val();


    $.ajax({
        type: 'post',
        url: './exec/edit_state.php',
        data: {index1: $select_state},
        success: function (response)

        {

            console.log(response);
            $ar = response.split(",");
            $str = '<option value="-1" selected disabled hidden ></option>';

            if (response.trim() != "")
            {
                for (var i = 0; i < $ar.length; i++)
                {
                    $ar1 = $ar[i].split(":");
                    $str += '<option value="' + $ar1[0] + '">' + $ar1[1] + "</option>";
                }
            } else {

            }
            $('#state_select').html($str);

        }
    });
});

$('body').on('click', '#btnedit', function () {



    $temp = $('#state_select').val();


    $state = $('#textedit').val();

if ($temp == null){
    alert('Select State');
}
if ($state == ""){
    alert('Enter a value');
}
else{

    $.ajax({
        type: 'post',
        url: 'exec/edit_state.php',
        data: {temp1: $temp, edit_state: $state},
        success: function (response)
        {
            alert('State name updated');
        }

    });
    }

});

$('body').on('click', '#btndelete', function () {

    $temp = $('#state_select').val();

if($temp == null)
{
    alert('Select State');
}
else{
    

    $.ajax({
        type: 'post',
        url: 'exec/edit_state.php',
        data: {temp2: $temp},
        success: function (response)
        {
alert('State Deleted');
        }
    });
    }
});
