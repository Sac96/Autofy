$('body').on('click', '#btnedit', function () {


    $temp = $('#country_select').val();
 
    $country = $('#textedit').val();
    
    if (($temp == null) && ($country == ""))
{
    alert('No value selected ');
}
else {

    $.ajax({
        type: 'post',
        url: 'exec/editcountry.php',
        data: {temp1:$temp,index1: $country},
        success: function (response)
        {
alert('Name updated');
        }

    });
    
}
});

$('body').on('click','#btndelete',function(){
   
   $temp = $('#country_select').val();
  
if ($temp == null)
{
    alert('No value selected ');
}
  
  
   $.ajax({
        type: 'post',
        url: 'exec/editcountry.php',
        data: {temp2:$temp},
        success: function (response)
        {
alert('Country updated');
        }
   });
});
