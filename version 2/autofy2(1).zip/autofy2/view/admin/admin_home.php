<?php
include_once './admin_header.php';
include_once './admin_menubar.php';
session_start();
?>

<?php
if (!$_SESSION["adlgid"]) {
    echo '<script> window.location.href="./index.php"</script>';
}
?>
<div class="jumbotron">
    <h2>
        <center> Welcome Admin </center>
    </h2>
</div>
<div >
    <center>
        <h3>Hello admin <br> Welcome to autofy here you can manage your locations and auto stands.</h3>
    </center>
</div>