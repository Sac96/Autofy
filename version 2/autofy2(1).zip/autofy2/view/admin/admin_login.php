
<?php
include_once '../../core/db.php';
include_once './admin_header.php';
?>

<?php
if (isset($_POST['login'])) {

    function CheckCaptcha($userResponse) {
        $fields_string = '';
        $fields = array(
            'secret' => '6LcuGjEUAAAAAMfRMhhVCN8lD5SZIjvtTj61JcOp',
            'response' => $userResponse
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);
        $res = curl_exec($ch);
        curl_close($ch);
        return json_decode($res, true);
    }
    // Call the function CheckCaptcha
    $result = CheckCaptcha($_POST['g-recaptcha-response']);

        if ($result['success']) {

        $uname = $_POST['uname'];
        $pass = $_POST['pass'];

        $pass = str_replace("'", "", $pass);

        $uname = str_replace("'", "", $uname);

        $res = mysqli_query($dbcon, "select admin_id,username,password from admin where username='$uname' and password='$pass' ");
        $row = mysqli_fetch_array($res);

        if ($row) {

            $_SESSION["adlgid"] = $row['admin_id'];

            echo'<script>window.location.href="./admin_home.php"</script>';
        } else {
            ?>
            <script>
                alert("invalid user");
            </script>
            <?php
        }
    } else {
        echo '<script> alert("Captcha Fail");</script>';
    }
}
?>



<head>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="icon" href="images/unnamed.png" type="icon">
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src="js/sidemenu.js"></script>
</head>

<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-4 col-md-offset-4">
            <h1 class="text-center login-title">Sign in as Admin</h1>
            <div class="account-wall">
                <img class="profile-img" src="images/photo.jpg.png" 
                     alt="">
                <form class="form-signin" method="post" action="">
                    <input type="text" name="uname" id="uname" class="form-control" placeholder="Email" required autofocus>
                    <input type="password" name="pass" id="pass" class="form-control" placeholder="Password" required>

                    <!--Site Key-->

                    <div class="g-recaptcha" data-sitekey="6LcuGjEUAAAAAK92iJhRvfxK3ij7nQV1KP6JPdrM"></div>



                    <input type="submit" class="btn btn-lg btn-primary btn-block" name="login" id="login" value="Log In">
                    <label class="checkbox pull-left">
                        <input type="checkbox" value="remember-me">
                        Remember me
                    </label>
                    <a href="#" class="pull-right need-help">Need help? </a><span class="clearfix"></span>

                </form>
            </div>

        </div>
    </div>
</div>

