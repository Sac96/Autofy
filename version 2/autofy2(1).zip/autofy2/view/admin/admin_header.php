<head>
    <link rel="stylesheet" href="./css/bootstrap.css">
    <link rel="stylesheet" href="./css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<script src="../../public/js/jquery.js"></script>
<script src="../../public/js/bootstrap.min.js"> </script>
