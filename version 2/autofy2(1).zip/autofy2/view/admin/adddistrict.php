

<?php
include_once '../../core/db.php';
include_once 'admin_header.php';
include_once './admin_menubar.php';
?>

<?php
if (!$_SESSION["adlgid"]) {
   echo '<script> window.location.href="../../index.php"</script>';
}
?>

<head>
    <link rel="icon" href="images/icon.png" type="icon">
</head>

<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3 col-sm-5 col-sm-offset-4">
            <div class="panel panel-primary" style="margin-top: 20px;">
                <div class="panel-heading" >Register your Auto!</div>
                <div class="panel-body">



                    <label for="states" class="m-t-10">Select your Country</label>



                    <select id="country_select" class="form-control" name="country" required=""> 
                        <option value="-1" disabled="" selected="">Country</option>
                        <?php
                        $res = mysqli_query($dbcon, "select * from country where status='1' ");

                        while ($row = mysqli_fetch_array($res)) {
                            echo '<option value=' . $row['country_id'] . '>' . $row['country_name'] . '</option>';
                        }
                        ?>
                    </select>


                    <label for="states" class="m-t-10">Select your State</label>
                    <select id="state_select" class="form-control" name="state" required="">   
                        <option value="-1" disabled selected>Select State</option>                        
                    </select>

                    <label for="statename"> Add New District</label>
                    <input type="text" id="add_district" class="form-control" onblur="check1()" name="add_state" placeholder="New District Name" required="">                         

                    <center><input type="button" onclick="check2()" class="btn btn-primary m-t-10" id="add" name="add" value="Add District" style="margin-top: 5px;"></center>

                    <br><label for="Heading"> Edit/Remove existing states </label><br><br>

                    <label for="states" class="m-t-10">Select your Country</label>



                    <select id="country_edit_select" class="form-control" name="country" required=""> 
                        <option>Country</option>
                        <?php
                        $res = mysqli_query($dbcon, "select * from country where status='1' ");

                        while ($row = mysqli_fetch_array($res)) {
                            echo '<option value=' . $row['country_id'] . '>' . $row['country_name'] . '</option>';
                        }
                        ?>
                    </select>

                    <label for="states" class="m-t-10">Select your State</label>
                    <select id="state_edit_select" class="form-control" name="state" required="">   
                        <option value="-1" disabled selected>Select State</option>                        
                    </select>

                    <label for="states" class="m-t-10">Select your District</label>
                    <select id="district_edit_select" class="form-control" name="state" required="">   
                        <option value="-1" disabled selected>Select District</option>                        
                    </select>

                    <label for="Driver Name"> Set new name </label>
                    <input type="text" id="textedit" class="form-control" name="textrdit" placeholder="State Name">  


                    <input type="button" class="btn btn-warning m-t-10" id="btnedit" name="btnedit" value="Edit" style="float: left;margin-top:5px; ">

                    <input type="button" class="btn btn-danger m-t-10" id="btndelete" name="btndelete" value="Delete" style="float: right;margin-top:5px;">





                </div>
            </div>
        </div>
    </div>
</div>  

<script>
    function check1() {


        $cs = $('#country_select').val();
        if ($cs == null) {
            alert("Select Country");
        }
        $css = $('#state_select').val();
        if ($cs == null) {
            alert("Select State");
        }

        $kkk = $('#add_district').val();

        $.ajax({
            type: 'post',
            url: 'exec/edit_district.php',
            data: {cty: $kkk},
            success: function (response)
            {
                if (response == 0)
                {
                    return true;
                } else {

                    alert('Data already exists');
                    return false;
                }

            }
        });
    }
    function check2() {
        var x = document.getElementById("add_district").value;
        if (x == "")
        {
            alert('Please enter valid name')
            return false;
        } else {
            return true;
        }
    }

</script>    




<script src="js/edit_district.js"></script>