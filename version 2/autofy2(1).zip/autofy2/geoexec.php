
<?php
include_once './core/db.php';
$usid=$_SESSION['lguid'];
$atoid=$_POST['atid2'];
$lat= $_POST['lat1']; //latitude
$lng= $_POST['long2']; //longitude
$mob=$_POST['phone'];


  

function send($sms, $to) {
    
        $sms = urlencode($sms);
      
            $url = 'http://sms.safechaser.com/httpapi/httpapi?token=a917e2ac067a1a6c6d4c40bdd9c47c6d&sender=EYAUTO&number='.$to.'&route=2&type=1&sms='.$sms;
        
            
            
            $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $datares = curl_exec($ch);
        curl_close($ch);
        return $datares;
    }

    
  //function getaddress($lat,$lng)
  //{
  //   $url1 = 'https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyAHyEyA84oRlSRJKLngGik6XSn42dCQLJQ&latlng='.trim($lat).','.trim($lng).'&sensor=false';
   //  echo $url1;
   //  $json = @file_get_contents($url1);
   //  $data=json_decode($json);
   //  $status = $data->status;
   //  if($status=="OK")
   //  {
   //    return $data->results[0]->formatted_address;
   //  }
     
 // }

  
  
  
 // $address= getaddress($lat,$lng);
  //if($address)
  //{
    //echo $address;
    
    


$msg="Hai my location is https://maps.google.com/maps?q=".$lat.",".$lng."+(My+Point)&z=14&ll=".$lat.",".$lng ;

send($msg,$mob);


$sql2="INSERT INTO `message`(`msg_content`, `user_id`, `auto_id`, `msg_status`) VALUES ('$msg','$usid','$atoid',1)";
$sql3= mysqli_query($dbcon, $sql2);   

  //}
  //else
  //{
    //echo "Not found";
  //}
?>