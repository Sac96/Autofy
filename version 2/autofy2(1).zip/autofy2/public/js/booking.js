


$('body').on('click', '#btsend1', function () {

    $bdt = $('#dtpicker').find("input").val();
    $bdp = $('#btsend1').val();
    $bdfrom = $('#bfrom').val();
    $bdto = $('#bto').val();
    $usr = $('#svalue').val();
    $atid = $('#atmob').val();
    $dmob=$('#ddmob').val();
    
    if($bdto==''){
        alert('Please fill full data');
        return false;
    }
    
    if($bdfrom==''){
        alert('Please fill full data');
        return false;
    }
    
    alert("Please note booking is only confirmed after a direct call to the driver");
    var r = confirm("Call driver now?!");
    
    $.ajax({
        type: 'post',
        url: './exec/bookings.php',
        data: {bktm: $bdt, bkno: $bdp, tfrom: $bdfrom, tto: $bdto, usr: $usr, atid: $atid},
        success: function (response)
        {
            alert('Booking complete');
        }

    });
    
});