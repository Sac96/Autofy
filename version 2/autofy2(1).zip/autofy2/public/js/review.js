$('body').on('click', '.review1', function () {

    $did = $(this).data('id');
    $dname = $(this).data('name');
    $dmob = $(this).data('mob');


    $.ajax({
        type: 'post',
        url: './review_pub.php',
        data: {did: $did, dname: $dname, dmob: $dmob},
        success: function (response)

        {

            $('#review' + $did).html(response);
        }
    });

});


$('body').on('click', '.rvadd', function () {


    $ui = $(this).data('user');
    $ai = $(this).data('id');
    $rh = $('#rhead'+ $ai).val();
    $rb = $('#rbody'+ $ai).val();


    $.ajax({
        type: 'post',
        url: './exec/review_add.php',
        data: {ui: $ui, ai: $ai, rh: $rh, rb: $rb},
        success: function (response)
        {
            alert(response);
        }
    });

});


$('body').on('click', '#dprofile', function () {

$aid=$(this).data('id');
$("#uprofilemodal").modal("toggle");

    $.ajax({
        type: 'post',
        url: './exec/driver_data.php',
        data: {did:$aid},
        success: function (response)
        {
            $('#apbody').html(response);
        }
    });

});



