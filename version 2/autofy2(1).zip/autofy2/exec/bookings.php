<?php

include_once '../core/db.php';

$fruser=$_POST['usr'];
$btm = $_POST['bktm'];
$bno = $_POST['bkno'];
$bfrom= $_POST['tfrom'];
$bto=$_POST['tto'];
$atid=$_POST['atid'];
$cdt=date("d/m/Y");


$qry3="select * from user where user_id=".$fruser;
$sql3=mysqli_query($dbcon,$qry3);
$res3=mysqli_fetch_array($sql3);
if ($res3){
    $bname=$res3['user_name'];
    $bmob=$res3['user_mob'];
}

?>
<?php

function send($sms, $to) {

    $sms = urlencode($sms);

    $url = 'http://sms.safechaser.com/httpapi/httpapi?token=a917e2ac067a1a6c6d4c40bdd9c47c6d&sender=EYAUTO&number=' . $to . '&route=2&type=1&sms=' . $sms;


    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 50);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $datares = curl_exec($ch);
    curl_close($ch);
    return $datares;
}
?>

<?php

$mob = $bno;
$msg = "Hello driver,You have a booking on ".$btm." from ".$bfrom." to ".$bto." by the user ".$bname."(".$bmob.") .Please reply your response via your autofy account ";
//send($msg, $mob);

$qqq="INSERT INTO `bookings`(`booking_msg`, `user_id`, `auto_id`) VALUES ('$msg','$fruser','$atid')";

$qqw="INSERT INTO `bookings`(`booking_msg`, `bkfrom`, `bkto`,`bkfor`, `bktime`, `user_id`, `auto_id`, `booking_status`) VALUES ('$msg','$bfrom','$bto','$btm','$cdt','$fruser','$atid',0)";

$sqli4= mysqli_query($dbcon, $qqw);   
?>