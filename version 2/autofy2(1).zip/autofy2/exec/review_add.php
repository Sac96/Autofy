<?php
include_once '../core/db.php';

$ui1=$_POST['ui'];
$ai1=$_POST['ai'];
$rh1=$_POST['rh'];
$rb1=$_POST['rb'];
$cdt=date("d/m/Y");

$qc="Select * from `review` where `auto_id`='$ai1' and `user_id`='$ui1' ";
$sqc= mysqli_query($dbcon, $qc);
$revs=mysqli_fetch_array($sqc);
if($revs){
    echo 'Review already added';
}
else{
 
$qq="INSERT INTO `review`(`review_head`, `review_sub`, `review_date`, `auto_id`, `user_id`) VALUES ('$rh1','$rb1','$cdt','$ai1','$ui1')";
$sql1= mysqli_query($dbcon, $qq);   

echo 'Review added';
}
?>