<?php

echo '<script> window.location.href="./view/admin/admin_login.php" </script>';

?>