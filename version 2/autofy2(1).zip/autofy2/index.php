<?php
include_once './core/db.php';

if (isset($_SESSION["autostand_lgid"])) {
    include_once './view/autostand/autostand_menubar2.php';
} elseif (isset($_SESSION["lguid"])) {
    include_once './view/user/user_menubar.php';
    ?>
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
        (function () {
            var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
            s1.async = true;
            s1.src = 'https://embed.tawk.to/5a62e01ed7591465c706ed41/default';
            s1.charset = 'UTF-8';
            s1.setAttribute('crossorigin', '*');
            s0.parentNode.insertBefore(s1, s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
    <?php
} else {
    include_once './public/public_menubar.php';
}
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">       
        <title>Aey Auto!</title>
        <link rel="stylesheet" href="public/css/bootstrap.css">
        <link rel="icon" href="public/images/unnamed.png" type="icon">
        <link rel="stylesheet" type="text/css" href="public/css/main.css">
        <link href="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css" rel="stylesheet">
        <link href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css" rel="stylesheet">
        <style>

            .m-t-10 {
                margin-top: 10px;
            }

            .show_error{
                display: inline;           
            }
            .hide_error{
                display: none;
            }
        </style>
        <script async="async" src="https://www.google.com/adsense/search/ads.js"></script>

<!-- other head elements from your page -->

<script type="text/javascript" charset="utf-8">
(function(g,o){g[o]=g[o]||function(){(g[o]['q']=g[o]['q']||[]).push(
  arguments)},g[o]['t']=1*new Date})(window,'_googCsa');
</script>


    </head>
    <script src="public/js/jquery.js"></script>


    <body>


        <div class="container-fluid" style="position:relative;">

            <div class="row">
                <div class="col-md-12" style="margin-top: 40px;">

                    <div id="csrch">
                        <center><input id="listplaces" class="btn dropdown-toggle btn-default" placeholder="Search your place" list="placess" name="place" style="width:30%;margin-bottom: 10px;">
                            <button type="button" id="listsearch" style="margin-top: -10px;" class="btn btn-primary"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button></center>
                    </div>
                    <datalist id="placess">
                        <?php
                        $respl = mysqli_query($dbcon, "select * from place where place_status='1' ");

                        while ($resplaces = mysqli_fetch_array($respl)) {
                            echo '<option data-psid=' . $resplaces['place_id'] . ' value=' . $resplaces['place_name'] . '></option>';
                        }
                        ?>">
                    </datalist>

                    <div id="fbtn">
                        <center> <button id="btnf" onclick="myFunctionb()" class="btn btn-toolbar">Filter Search</button></center>
                    </div>

                    <script>
                        function myFunctionb() {
                            var x = document.getElementById("fsearch");
                            var y = document.getElementById("fbtn");
                            var z = document.getElementById("csrch");
                            if (x.style.display === "none") {
                                x.style.display = "block";
                                y.style.display = "none";
                                z.style.display = "none";
                            } else {
                                x.style.display = "none";
                            }
                        }
                    </script>

                    <div id="fsearch" class="col-md-12" style="display:none;">
                        <div class="col-md-3">

                            <select class="form-control" style="opacity: 100px" id="country_select"> <option selected="" disabled="" value="-1">Country</option>

                                <?php
                                $res = mysqli_query($dbcon, "select * from country where status='1' ");
//                            $res2 = mysqli_query($dbcon, "select * from state where status='1' ");

                                while ($row = mysqli_fetch_array($res)) {
                                    echo '<option value=' . $row['country_id'] . '>' . $row['country_name'] . '</option>';
                                }
                                ?>

                            </select>
                        </div>
                        <div class="col-md-3">

                            <select class="form-control" id="state_select" > <option value="-1" disabled="" selected="">State</option>
                            </select>

                        </div>
                        <div class="col-md-3 col-sm-3">

                            <select class="form-control" style="opacity: 100px" id="district_select"> <option>District</option></select>

                        </div>
                        <div class="col-md-3" col-sm-3>

                            <select class="form-control" style="opacity: 100px" id="place_select"> <option>Place</option></select>

                        </div>
                        <div class="col-md-offset-5 col-sm-3" style="margin-top: 10px;">
                            <input type="button" id="find" class="btn btn-block btn-success " style="width: 250px; " value="Find Nearest Auto!">
                        </div>
                    </div>
                </div>
            </div>





            <center><div class="row col-md-12 hide_error " style="color:white; font-size: 60px;" id="place_error" >Error</div></center>

        </div>    

        <div class="container-fluid">
            <div id="find_autostand">

            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Book your Auto</h4>
                    </div>
                    <div class="modal-body">
                        <label>From</label>
                        <input type="text" class="form-control" id="bfrom">
                        <label>To</label>
                        <input type="text" class="form-control" id="bto">
                        <label>Select date and time</label>
                        <input type="hidden" value="<?php echo $_SESSION["lguid"]; ?>" id="svalue">
                        <input type="hidden" id="atmob">

                        <form>
                            <div class='input-group date' id="dtpicker">
                                <input type='text' class="form-control" value="" />
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>

                                </span>
                            </div>
                        </form>
                        <script type="text/javascript">
                            $(function () {
                                var dt = Date.now();
                                var date = new Date();
                                var dtp = date.setDate(date.getDate() + 5);
                                $('#dtpicker').datetimepicker({
                                    minDate: dt,
                                    maxDate: dtp
                                });
                            });
                        </script>
                                                    <!--<input type="datetime" value="" class="cdtpicker" name="dtpicker" id="dtpicker">-->


                    </div>
                    <div class="modal-footer">
                        <button type="button" id="btsend1" class="btn btn-primary"  data-mob="" >Book Now</button>

                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
                <!--Modal Content Ends-->
            </div>
        </div>
        <!--Modal ends-->



        <!-- Modal -->
        <div class="modal fade" id="uprofilemodal" role="dialog">


            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content" style="background-color: beige;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Driver Details</h4>
                    </div>
                    <div class="modal-body" id="apbody" >

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
                <!--Modal Content Ends-->
            </div>

        </div>
        <!--Modal ends-->

        <br><br><br><br>
        
    <div id='afscontainer1'></div>

<script type="text/javascript" charset="utf-8">

  var pageOptions = {
    "pubId": "pub-9616389000213823", // Make sure this the correct client ID!
    "query": "Taxi",
    "adPage": 1
  };

  var adblock1 = {
    "container": "afscontainer1",
    "width": "1390",
    "height": "800",
    "number": 3
  };

  _googCsa('ads', pageOptions, adblock1);

</script>




        <script type="text/javascript">
            function googleTranslateElementInit() {
                new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
            }
        </script>

    </body>

    <script src="public/js/location.js" ></script>
    <script src="public/js/review.js"></script>
    <script src="public/js/booking.js"></script>


    <script>
            $(document).on('click', '.panel-heading span.clickable', function (e) {
                var $this = $(this);
                if (!$this.hasClass('panel-collapsed')) {
                    $this.parents('.panel').find('.panel-body').slideUp();
                    $this.addClass('panel-collapsed');
                    $this.find('i').removeClass('glyphicon-minus').addClass('glyphicon-plus');
                } else {
                    $this.parents('.panel').find('.panel-body').slideDown();
                    $this.removeClass('panel-collapsed');
                    $this.find('i').removeClass('glyphicon-plus').addClass('glyphicon-minus');
                }
            });
            $(document).on('click', '.panel div.clickable', function (e) {
                var $this = $(this);
                if (!$this.hasClass('panel-collapsed')) {
                    $this.parents('.panel').find('.panel-body').slideUp();
                    $this.addClass('panel-collapsed');
                    $this.find('i').removeClass('glyphicon-minus').addClass('glyphicon-plus');
                } else {
                    $this.parents('.panel').find('.panel-body').slideDown();
                    $this.removeClass('panel-collapsed');
                    $this.find('i').removeClass('glyphicon-plus').addClass('glyphicon-minus');
                }
            });
            $(document).ready(function () {
                $('.panel-heading span.clickable').click();
                $('.panel div.clickable').click();
            });


    </script>
    <script>

        $('#myModal').on('show.bs.modal', function () {

        });

        $('body').on('click', '#bkbtn', function () {
            $phone = $(this).data('phone');
            $('#btsend1').val($phone);
            $atid = $(this).data('atid');
            $('#atmob').val($atid);
        });
    </script>

    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js"></script>
    <script src="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/src/js/bootstrap-datetimepicker.js"></script>
</html>

