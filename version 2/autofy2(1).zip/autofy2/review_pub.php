<?php
include_once './public_header.php';
include_once './core/db.php';
?>
<?php

if(isset($_SESSION["lguid"])){
$user_id = $_SESSION["lguid"];
}
$aa = $_POST['did'];
$sqlf = "Select * from review where auto_id=" . $aa;
$sqlff = mysqli_query($dbcon, $sqlf);
while ($result2 = mysqli_fetch_array($sqlff)) {

    $head = $result2['review_head'];
    $subject = $result2['review_sub'];
    $dat = $result2['review_date'];
    ?>
    <div class="container-fluid panel">
        <div class="row panel-body" style="margin-bottom: 10px;">
            <div class="col-md-3 col-md-offset-9"></div>
            <div class="col-md-9" style="font-size: 20px; ">
                <b style="color:blue;"><i><?php echo  $head; ?> </i></b>:<p><?php echo $subject; ?> </p></div>
        <div class="col-md-3">Reviewed on:<?php echo $dat;  ?></div>
             </div>

    </div>

    <?php
}
?>
<?php 
if(isset($_SESSION["lguid"])){ ?>


<div class="col-md-12">
    <label>Write a review</label><br/>
    <input type="text" id="rhead<?php echo $aa ; ?>" name="rbody" class="form-control" style="width: 200px;" placeholder="Header here"><br/>
    <textarea id="rbody<?php echo $aa ; ?>" name="rbody" class="form-group" style="height: 200px; width: 400px;" placeholder="Description here"></textarea><br/>
    <input type="button"  id="rbtn" <?php echo 'data-id="' . $aa . '" data-user="' . $user_id . '" ' ?> value="Submit Review" class="btn btn-info rvadd" name="rbtn" style="margin-bottom: 20px;" >
</div>

<?php } ?>

