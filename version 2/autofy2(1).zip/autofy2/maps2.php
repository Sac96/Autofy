<?php
include_once './public_header.php';
include_once './core/db.php';

if(isset($_SESSION["lguid"])){
    include_once './view/user/user_menubar.php';
    
}
else{
    include_once './public/public_menubar.php';
}



?>






<head>

    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1"></meta>
    <meta charset="UTF-8">  </meta>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"></link>
    <style type="text/css">
        body
        {         
            width: 100%;
            height: 100%;
        }
        label{
            font-size: 20px;
            font-family: cursive;
        }
    </style>
</head>

<body >

    <div style="background-image:url('public/images/mapsbg.jpg'); width: 100%; height: 250px; ">
        <div style="width:50%;   float: left; height: 250px; padding: 50 100; overflow: hidden;">
            <label>  Source:</label>
            <input type="text" id="txtSource" class="form-control " value="" style="font-size: 25;" placeholder="Type your Source"  />
            <label> Destination: </label>
            <input type="text" id="txtDestination" class="form-control " style="font-size: 25;" value="" placeholder="Type your Destination" />

            <input type="button" class="btn btn-success" style="margin-top: 10px;" value="Get Route" onclick="GetRoute()" />

        </div>


        <div style="width:50%; height: 250px; float: right; padding: 50 100;">

            <label>Check fare for travel</label>
            <input type="text" id="km1" class=" form-control" style="font-size: 25;"/>

            <input type="button" value="Find Fare" style="margin-top: 10px;" onclick="addNumbers()" class="btn btn-primary"/><br/>

            <label>  Autorickshaw fare for travel is </label><br/>

            <input type="text" id="km2" class=" form-control" style="color: white;background-color: red;font-size: 25;"/>


        </div>
    </div>

    <div class="bg-info">
       <marquee behavior="alternate" direction="up" width="100%">
           <marquee direction="right" behavior="alternate"><h3 >Minimum charge for travel is Rs.20/1.5km . An amount of Rs.1 will be added for further 100m </h3></marquee>
</marquee>
    </div>


    <div>
        <div id="dvDistance" >
        </div>
    </div>
    
    <div>
    <div id="dvMap" style="width:50%; height:500px; float: left;" >
    </div>

    <div id="dvPanel" style="width:50%; float: right; margin-top: -10px;" >
    </div>

    </div>

</body>
<script  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAHyEyA84oRlSRJKLngGik6XSn42dCQLJQ&sensor=false&libraries=places"
type="text/javascript"></script>
          <!--<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>async defer-->
<script type="text/javascript">
                var source, destination;
                var directionsDisplay;
                var directionsService = new google.maps.DirectionsService();
                google.maps.event.addDomListener(window, 'load', function () {
                    new google.maps.places.SearchBox(document.getElementById('txtSource'));
                    new google.maps.places.SearchBox(document.getElementById('txtDestination'));
                    directionsDisplay = new google.maps.DirectionsRenderer({'draggable': true});
                });

                function GetRoute() {
                    var mumbai = new google.maps.LatLng(18.9750, 72.8258);
                    var mapOptions = {
                        zoom: 7,
                        center: mumbai
                    };
                    map = new google.maps.Map(document.getElementById('dvMap'), mapOptions);
                    directionsDisplay.setMap(map);
                    directionsDisplay.setPanel(document.getElementById('dvPanel'));

                    //*********DIRECTIONS AND ROUTE**********************//
                    source = document.getElementById("txtSource").value;
                    destination = document.getElementById("txtDestination").value;

                    var request = {
                        origin: source,
                        destination: destination,
                        travelMode: google.maps.TravelMode.DRIVING
                    };
                    directionsService.route(request, function (response, status) {
                        if (status == google.maps.DirectionsStatus.OK) {
                            directionsDisplay.setDirections(response);
                        }
                    });

                    //*********DISTANCE AND DURATION**********************//
                    var service = new google.maps.DistanceMatrixService();
                    service.getDistanceMatrix({
                        origins: [source],
                        destinations: [destination],
                        travelMode: google.maps.TravelMode.DRIVING,
                        unitSystem: google.maps.UnitSystem.METRIC,
                        avoidHighways: false,
                        avoidTolls: false
                    }, function (response, status) {
                        if (status == google.maps.DistanceMatrixStatus.OK && response.rows[0].elements[0].status != "ZERO_RESULTS") {
                            var distance = response.rows[0].elements[0].distance.value / 1000;
                            var duration = response.rows[0].elements[0].duration.text;
                            var dvDistance = document.getElementById("dvDistance");
                            dvDistance.innerHTML = "";
                            dvDistance.innerHTML += "Distance: " + distance + " Km<br />";
                            dvDistance.innerHTML += "Duration:" + duration;



                            document.getElementById("km1").value = distance;

                        } else {
                            alert("Unable to find the distance via road.");
                        }
                    });

                }
</script>
<script language="javascript">
    function addNumbers()
    {
        var val1 = (document.getElementById("km1").value);
        var val2 = 20
        var ansD = document.getElementById("km2");
        if (val1 <= 1.5)
        {
            ansD.value = val2;
        } else
        {
            var bal = val1 - 1.5;
            
            var res = bal * 10;
            ansD.value = 20 + res;
        }


    }

</script>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
</html>

