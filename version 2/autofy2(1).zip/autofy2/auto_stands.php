<?php
include_once './core/db.php';
include_once './public_header.php';
?>


<?php
if (!isset($_POST['data'])) {
    echo '<h3 style="color:white;">No results found</h3>';
    die;
}

$standlist = $_POST['data'];

if ($standlist == 'Place') {
    echo '<h3 style="color:red;">No results found</h3>';
    die;
} elseif ($standlist == '') {
    echo '<h3 style="color:blue;">No results found</h3>';
    die;
}

//if ((isset($_POST['data']) == FALSE) ) {
//
//
//    echo '<h3 style="color:white;">No results found</h3>';
//    die;
//} 
else {
    if ($_POST['data'] != "-1") {


        $sql = "SELECT * FROM `autostand` where `place_id`='" . $standlist . "' AND `status` =1";
        $qry = mysqli_query($dbcon, $sql);
        ?>


        <head>
            <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta charset="UTF-8">   
            <style>

                .clickable
                {
                    cursor: pointer;
                }

                .clickable .glyphicon
                {
                    background: rgba(0, 0, 0, 0.15);
                    display: inline-block;
                    padding: 6px 12px;
                    border-radius: 4px
                }

                .panel-heading span
                {
                    margin-top: -23px;
                    font-size: 15px;
                    margin-right: -9px;
                }
                a.clickable { color: inherit; }
                a.clickable:hover { text-decoration:none; }
            </style>
        </head>

        <h4 style="color:white;">
            Nearby Autostands are
        </h4>


        <?php
        while ($result = mysqli_fetch_array($qry)) {
            $a = $result['autostand_id'];
            $b = $result['autostand_name'];
            $atlat = $result['lat'];
            $atlon = $result['lon'];

            $myres = mysqli_query($dbcon, "SELECT count(`status`) FROM `auto` WHERE `autostand_id`=" . $a . " and `status` like 1");
            $myrow = mysqli_fetch_array($myres);
            ?>

            <div class="panel panel-info"> 
                <div class="panel-heading clickable">
                    <center><b>Available Autos:<?php echo $myrow[0]; ?> </b></center>
                    <h3 class="panel-title"> 
                        <?php echo $b; ?>
                        <a target="_blank_" style="float:right;color: red;margin-right: 35px;" href="https://www.google.com/maps/search/?api=1&query=<?php echo $atlat; ?>,<?php echo $atlon; ?>" >Get Stand's Location</a>

                    </h3>

                    <?php
                    if ((!isset($_SESSION["lguid"])) && (!isset($_SESSION["autostand_lgid"]))) {
                        
                    } else {
                        ?> 
                        <span class="pull-right "><i class="glyphicon glyphicon-minus"></i></span>
                    <?php } ?>


                </div>

                <?php
                if ((!isset($_SESSION["lguid"])) && (!isset($_SESSION["autostand_lgid"]))) {
                    
                } else {
                    ?>



                    <div class="panel-body">




                        <?php if (isset($_SESSION["autostand_lgid"])) { ?>
                            <center><b  style="font-size:20px;"> <div class="col-md-2">Driver Name</div> 
                                    <div class="col-md-2">Phone</div> 
                                    <div class="col-md-2">Status</div> 
                                    <div class="col-md-2">Review</div> 
                                    <div class="col-md-2">Send Location</div> </b></center>
                            <div><hr size="15px"></div>
                        <?php } ?>

                        <?php if (isset($_SESSION["lguid"])) { ?>
                            <center><b  style="font-size:20px;"> <div class="col-md-2">Driver Name</div> 
                                    <div class="col-md-2">Phone</div> 
                                    <div class="col-md-2">Status</div> 
                                    <div class="col-md-2">Review</div> 
                                    <div class="col-md-2">Send Location</div> 
                                    <div class="col-md-2">Book Auto</div> </b></center>
                            <div><hr size="15px"></div>
                        <?php } if ((!isset($_SESSION["lguid"])) && (!isset($_SESSION["autostand_lgid"]))) { ?>
                    <!--                        <center><b  style="font-size:20px;"> <div class="col-md-3">Driver Name</div> 
                                        <div class="col-md-3">Phone</div> 
                                        <div class="col-md-3">Status</div>                            
                                        <div class="col-md-3">Send Location</div> </b></center>
                                <div><hr size="15px"></div>-->
                        <?php } ?>

                        <?php
                        $autos = mysqli_query($dbcon, "SELECT * FROM `auto` WHERE `autostand_id`='" . $a . "' AND `status` >=1");
                        while ($result2 = mysqli_fetch_array($autos)) {
                            $c = $result2['driver_mob'];
                            $d = $result2['driver_name'];
                            $f = $result2['status'];
                            $g = $result2['auto_id'];

//                        $_SESSION['dname'] = $d;
//                        $_SESSION['did'] = $g;
//                        $_SESSION['dmob'] = $c;


                            if ($f == 1) {
                                $f = '<i class="fa fa-circle" style="color:green; margin-right:30px;" aria-hidden="true"></i>Availiable';
                            } elseif ($f == 2) {
                                $f = '<i class="fa fa-circle" style="color:orange; margin-right:30px;" aria-hidden="true"></i>Busy';
                            } elseif ($f == 3) {
                                $f = '<i class="fa fa-circle" style="color:red; margin-right:30px;" aria-hidden="true"></i>Not Availiable';
                            } elseif ($f == 4) {
                                $f = '<i class="fa fa-circle" style="color:red; margin-right:30px;" aria-hidden="true"></i>Coming Soon';
                            }

                            if (isset($_SESSION["autostand_lgid"])) {

                                echo '<div class="row" style="margin-bottom:30px;" >';
                                echo '<center style="font-size:18px;"><div class="col-md-2" ><div style="float:left;"><i class="fa fa-user fa-1x" aria-hidden="true"></i></div>&nbsp;' . $d . '</div>';
                                echo '<div class="col-md-2"><i class="fa fa-phone fa-1x" aria-hidden="true"></i>&nbsp;<a href="tel:' . $c . '">' . $c . '</a></div>';
                                echo '<div class="col-md-2">' . $f . '</div>';
                                echo '<div class="col-md-2"><input type="button" value="Review" class="review1 btn btn-primary" data-id="' . $g . '" data-mob="' . $c . '" data-name="' . $d . '"></div>';
                                echo '<div class="col-md-2"><input type="button" value="Send Location" class="sendlocid btn btn-primary" data-phone="' . $c . '" data-atid="' . $g . '" ></div></center>';



                                echo '</div>';
                                ?>

                                <div class="col-md-12" id="review<?php echo $g; ?>">

                                </div>



                                <?php
                            }


                            if (isset($_SESSION["lguid"])) {

                                echo '<div class="row" style="margin-bottom:30px;" >';
                                echo '<center style="font-size:18px;"><div class="col-md-2" ><div style="float:left;"><i class="fa fa-user fa-1x" aria-hidden="true"></i></div>&nbsp;<a  id="dprofile" data-id="' . $g . '" >' . $d . '</a></p></div>';
                                echo '<div class="col-md-2"><i class="fa fa-phone fa-1x" aria-hidden="true"></i>&nbsp;<a href="tel:' . $c . '">' . $c . '</a></div>';
                                echo '<div class="col-md-2">' . $f . '</div>';
                                echo '<div class="col-md-2"><input type="button" value="Review" class="review1 btn btn-primary" data-id="' . $g . '" data-mob="' . $c . '" data-name="' . $d . '"></div>';
                                echo '<div class="col-md-2"><input type="button" value="Send Location" class="sendlocid btn btn-primary" data-phone="' . $c . '" data-atid="' . $g . '" ></div>';
                                echo '<div class="col-md-2"><input type="button" id="bkbtn" data-toggle="modal" data-target="#myModal" value="Book Auto" class=" btn btn-primary" data-phone="' . $c . '" data-atid="' . $g . '" ></div></center>';
                                echo '<input type="hidden" id="ddmob" value=' . $c . '>';

                                echo '</div>';
                                ?>

                                <div class="col-md-12" id="review<?php echo $g; ?>">

                                </div>

                                <?php
                            } if ((!isset($_SESSION["lguid"])) && (!isset($_SESSION["autostand_lgid"]))) {

                                echo '<div class="row" style="margin-bottom:30px;" >';
                                echo '<center style="font-size:18px;"><div class="col-md-3" ><div style="float:left;"><i class="fa fa-user fa-1x" aria-hidden="true"></i></div>&nbsp;' . $d . '</div>';
                                echo '<div class="col-md-3"><i class="fa fa-phone fa-1x" aria-hidden="true"></i>&nbsp;<a href="tel:' . $c . '">' . $c . '</a></div>';
                                echo '<div class="col-md-3">' . $f . '</div>';
                                echo '<div class="col-md-3">Sign Up for Sending Location</div>';


                                echo '</div>';
                            }
                        }
                        ?>
                    </div>

                <?php } ?>
            </div><?php
        }
    }
}
?>
   







